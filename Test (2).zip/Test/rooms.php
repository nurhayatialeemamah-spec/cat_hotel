<?php
session_start();
require_once __DIR__ . '/db_connect.php';
$conn->set_charset('utf8mb4');

$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['name'] ?? '';
$role = $_SESSION['role'] ?? null;

function h($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

// ดึงข้อมูลห้องทั้งหมดพร้อมคำนวณห้องว่างถูกต้อง
$rooms_query = "SELECT r.*, 
                COALESCE(b.used_rooms, 0) AS used_rooms,
                (r.capacity - COALESCE(b.used_rooms, 0)) AS available_rooms
                FROM rooms r
                LEFT JOIN (
                    SELECT rooms_id, COUNT(*) AS used_rooms
                    FROM bookings
                    WHERE status IN ('Pending','Confirmed','Paid','Occupied')
                      AND end_date > NOW()
                      AND start_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)
                    GROUP BY rooms_id
                ) b ON r.rooms_id = b.rooms_id
                ORDER BY r.price_per_day ASC";

$rooms = $conn->query($rooms_query);

function roomImagePath($roomId)
{
    $base = 'assets/images/';
    $candidates = [
        $base . "room{$roomId}.jpg",
        $base . "room{$roomId}.png",
        $base . 'room-default.jpg',
    ];
    foreach ($candidates as $path) {
        if (is_file(__DIR__ . '/' . $path))
            return $path;
    }
    return $base . 'room-default.jpg';
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ห้องพักของเรา - Cat Hotel</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/rooms_style.css">
    
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <div class="container section">
        <div class="topbar">
            <h1 class="section-title" style="margin-right:auto">🐾 Cat Hotel</h1>
            <?php if ($user_id): ?>
                <span>สวัสดี <?= h($user_name) ?></span>
                <a class="btn" href="index.php">หน้าหลัก</a>
                <?php if ($role === 'admin' || $role === 'staff'): ?>
                    <a class="btn" href="admin.php">แดชบอร์ด</a>
                <?php else: ?>
                    <a class="btn" href="dashboard.php">แดชบอร์ด</a>
                <?php endif; ?>
                <a class="btn" href="logout.php">ออกจากระบบ</a>
            <?php else: ?>
                <a class="btn" href="index.php">หน้าหลัก</a>
                <a class="btn" href="login.php">เข้าสู่ระบบ</a>
                <a class="btn primary" href="register.php">สมัครสมาชิก</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1>ห้องพักของเรา</h1>
            <p>เลือกห้องพักที่เหมาะสมกับน้องแมวของคุณ พร้อมสิ่งอำนวยความสะดวกครบครัน</p>
        </div>
    </div>

    <!-- Rooms Grid -->
    <div class="container section">
        <div class="rooms-grid">
            <?php if ($rooms && $rooms->num_rows > 0): ?>
                <?php while ($room = $rooms->fetch_assoc()):
                    $roomId = (int) $room['rooms_id'];
                    $type = $room['type'] ?? 'Standard';
                    $size = $room['size'] ?? 'N/A';
                    $capacity = (int) $room['capacity'];
                    $maxCats = (int) ($room['max_cats'] ?? 1);
                    $priceDay = (float) $room['price_per_day'];
                    $priceHour = (float) $room['price_per_hour'];
                    $available = (int) $room['available_rooms'];
                    $used = (int) $room['used_rooms'];
                    $description = $room['description'] ?? '';
                    $img = roomImagePath($roomId);

                    // กำหนดสถานะห้องว่าง
                    $availStatus = '';
                    $availText = '';
                    if ($available <= 0) {
                        $availStatus = 'full';
                        $availText = 'เต็มแล้ว';
                    } elseif ($available <= 2) {
                        $availStatus = 'limited';
                        $availText = "เหลืออีก {$available} ห้อง";
                    } else {
                        $availStatus = 'available';
                        $availText = "ว่าง {$available}/{$capacity} ห้อง";
                    }
                    ?>
                    <div class="room-item">
                        <div class="room-image">
                            <img src="<?= h($img) ?>" alt="<?= h($type) ?>" onerror="this.src='assets/images/room-default.jpg'">
                            <div class="room-badge"><?= h($type) ?></div>
                            <div class="room-status-overlay <?= $availStatus ?>">
                                <?= $availText ?>
                            </div>
                        </div>

                        <div class="room-content">
                            <div class="room-type">ห้องหมายเลข #<?= $roomId ?></div>
                            <h2 class="room-title"><?= h($type) ?> Room</h2>
                            <div class="room-size">
                                📏 ขนาดห้อง: <?= h($size) ?>
                            </div>

                            <?php if ($description): ?>
                                <p class="room-description">
                                    <?= h($description) ?>
                                </p>
                            <?php endif; ?>

                            <div class="room-features">
                                <div class="feature-item">
                                    <span class="feature-icon">❄️</span>
                                    <span>แอร์ 24 ชม.</span>
                                </div>
                                <div class="feature-item">
                                    <span class="feature-icon">📹</span>
                                    <span>กล้อง CCTV</span>
                                </div>
                                <div class="feature-item">
                                    <span class="feature-icon">🌾</span>
                                    <span>ทรายแมวฟรี</span>
                                </div>
                                <div class="feature-item">
                                    <span class="feature-icon">💧</span>
                                    <span>น้ำพุแมว</span>
                                </div>
                            </div>

                            <div class="room-price-section">
                                <div class="price-info">
                                    <div class="price-label">เริ่มต้น</div>
                                    <div>
                                        <span class="price-amount"><?= number_format($priceDay, 0) ?></span>
                                        <span class="price-unit">บาท/คืน</span>
                                    </div>
                                    <?php if ($priceHour > 0): ?>
                                        <div class="price-hourly">
                                            (<?= number_format($priceHour, 0) ?> บาท/ชม.)
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="capacity-info">
                                    <div class="capacity-badge">
                                        <span class="badge-icon">🐱</span>
                                        รองรับ <?= $maxCats ?> ตัว
                                    </div>
                                    <div class="availability-badge <?= $availStatus ?>">
                                        <?= $availText ?>
                                    </div>
                                </div>
                            </div>

                            <div class="room-actions">
                                <button onclick="showRoomDetail(<?= $roomId ?>)" class="btn-info">
                                    ดูรายละเอียด
                                </button>
                                <?php if ($user_id): ?>
                                    <?php if ($available > 0): ?>
                                        <a href="booking.php?room_id=<?= $roomId ?>" class="btn-book">
                                            จองห้องนี้
                                        </a>
                                    <?php else: ?>
                                        <button class="btn-book disabled" disabled>
                                            ห้องเต็ม
                                        </button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="login.php" class="btn-book">
                                        เข้าสู่ระบบเพื่อจอง
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <p>ขณะนี้ยังไม่มีห้องพักในระบบ</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Info Section -->
    <div class="info-section">
        <div class="container">
            <h2 class="section-title">สิ่งอำนวยความสะดวก</h2>
            <p class="section-subtitle">
                บริการและสิ่งอำนวยความสะดวกที่เราเตรียมไว้ให้น้องแมวของคุณ
            </p>

            <div class="info-grid">
                <div class="info-card">
                    <div class="info-icon">📹</div>
                    <h3>กล้อง CCTV ฟรี</h3>
                    <p>ส่องน้องแมวได้ตลอด 24 ชั่วโมง ผ่านระบบออนไลน์</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">❄️</div>
                    <h3>ห้องแอร์ตลอดเวลา</h3>
                    <p>อุณหภูมิที่เหมาะสม พร้อมเครื่องฟอกอากาศ</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">🌾</div>
                    <h3>ทรายข้าวสาลีออร์แกนิก</h3>
                    <p>ของว่างเพื่อสุขภาพสำหรับน้องแมว</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">💧</div>
                    <h3>น้ำพุแมว</h3>
                    <p>น้ำสะอาดไหลเวียนตลอดเวลา (VIP ขึ้นไป)</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">😊</div>
                    <h3>โซนเดินเล่น</h3>
                    <p>พาน้องออกมาเล่นวันละ 2 รอบ รอบละ 30 นาที</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">👨‍⚕️</div>
                    <h3>ดูแลตลอด 24 ชม.</h3>
                    <p>พี่เลี้ยงและเจ้าของคอยดูแลใกล้ชิด</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal รายละเอียดห้อง -->
    <div id="roomModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal()">&times;</span>
            <div id="modalBody"></div>
        </div>
    </div>

    <script>
        // ข้อมูลห้องทั้งหมด
        const roomsData = {
            <?php
            $rooms->data_seek(0);
            while ($room = $rooms->fetch_assoc()):
                $roomId = (int) $room['rooms_id'];
                $available = (int) $room['available_rooms'];
                ?>
            <?= $roomId ?>: {
                    id: <?= $roomId ?>,
                    type: "<?= addslashes($room['type']) ?>",
                    size: "<?= addslashes($room['size']) ?>",
                    capacity: <?= (int) $room['capacity'] ?>,
                    maxCats: <?= (int) $room['max_cats'] ?>,
                    priceDay: <?= (float) $room['price_per_day'] ?>,
                    priceHour: <?= (float) $room['price_per_hour'] ?>,
                    available: <?= $available ?>,
                    used: <?= (int) $room['used_rooms'] ?>,
                    description: "<?= addslashes($room['description']) ?>",
                    image: "<?= addslashes(roomImagePath($roomId)) ?>"
                },
            <?php endwhile; ?>
        };

        function showRoomDetail(roomId) {
            const room = roomsData[roomId];
            if (!room) return;

            let availText = '';
            if (room.available <= 0) {
                availText = '<span class="badge-full">เต็มแล้ว</span>';
            } else if (room.available <= 2) {
                availText = `<span class="badge-limited">เหลืออีก ${room.available} ห้อง</span>`;
            } else {
                availText = `<span class="badge-available">ว่าง ${room.available}/${room.capacity} ห้อง</span>`;
            }

            const modalContent = `
            <div class="modal-header">
                <h2>${room.type} Room</h2>
                <p class="modal-subtitle">ห้องหมายเลข #${room.id}</p>
            </div>
            <div class="modal-body">
                <img src="${room.image}" alt="${room.type}" class="modal-image" 
                     onerror="this.src='assets/images/room-default.jpg'">
                
                <div class="modal-info-grid">
                    <div class="modal-info-item">
                        <span class="info-icon">📏</span>
                        <div>
                            <strong>ขนาดห้อง</strong>
                            <p>${room.size}</p>
                        </div>
                    </div>
                    <div class="modal-info-item">
                        <span class="info-icon">🐱</span>
                        <div>
                            <strong>รองรับแมว</strong>
                            <p>สูงสุด ${room.maxCats} ตัว</p>
                        </div>
                    </div>
                    <div class="modal-info-item">
                        <span class="info-icon">🏠</span>
                        <div>
                            <strong>จำนวนห้อง</strong>
                            <p>${room.capacity} ห้อง</p>
                        </div>
                    </div>
                    <div class="modal-info-item">
                        <span class="info-icon">✅</span>
                        <div>
                            <strong>สถานะ</strong>
                            <p>${availText}</p>
                        </div>
                    </div>
                </div>

                <div class="modal-description">
                    <h3>รายละเอียด</h3>
                    <p>${room.description || 'ห้องพักสะดวกสบาย พร้อมสิ่งอำนวยความสะดวกครบครัน'}</p>
                </div>

                <div class="modal-features">
                    <h3>สิ่งอำนวยความสะดวก</h3>
                    <ul>
                        <li>❄️ เครื่องปรับอากาศ 24 ชั่วโมง</li>
                        <li>📹 กล้อง CCTV ส่องดูได้ตลอดเวลา</li>
                        <li>🌾 ทรายแมวออร์แกนิก (ฟรี)</li>
                        <li>💧 ชามน้ำและอาหารส่วนตัว</li>
                        <li>🛏️ เตียงนอนและชั้นปีนป่าย</li>
                        <li>🎾 ของเล่นสำหรับน้องแมว</li>
                        <li>👨‍⚕️ พี่เลี้ยงดูแลตลอด 24 ชม.</li>
                    </ul>
                </div>

                <div class="modal-pricing">
                    <h3>ราคา</h3>
                    <div class="pricing-details">
                        <div class="price-row">
                            <span>รายวัน</span>
                            <strong>${room.priceDay.toLocaleString()} บาท/คืน</strong>
                        </div>
                        ${room.priceHour > 0 ? `
                        <div class="price-row">
                            <span>รายชั่วโมง</span>
                            <strong>${room.priceHour.toLocaleString()} บาท/ชม.</strong>
                        </div>
                        ` : ''}
                    </div>
                </div>

                <div class="modal-actions">
                    ${room.available > 0 ?
                    `<a href="booking.php?room_id=${room.id}" class="btn-book-modal">จองห้องนี้เลย</a>` :
                    `<button class="btn-book-modal disabled" disabled>ห้องเต็ม</button>`
                }
                    <button onclick="closeModal()" class="btn-cancel-modal">ปิด</button>
                </div>
            </div>
        `;

            document.getElementById('modalBody').innerHTML = modalContent;
            document.getElementById('roomModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('roomModal').style.display = 'none';
        }

        // ปิด modal เมื่อคลิกนอก modal
        window.onclick = function (event) {
            const modal = document.getElementById('roomModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>

</html>