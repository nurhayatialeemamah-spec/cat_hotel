<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

// ถ้ามี ID แสดงว่าเป็นการแก้ไข
$edit_mode = false;
$room = null;

if (isset($_GET['id'])) {
    $edit_mode = true;
    $room_id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM rooms WHERE rooms_id = $room_id");
    $room = $result->fetch_assoc();

    if (!$room) {
        header("Location: admin.php?tab=rooms");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $conn->real_escape_string($_POST['type']);
    $size = $conn->real_escape_string($_POST['size']);
    $capacity = intval($_POST['capacity']);
    $max_cats = intval($_POST['max_cats']);
    $price_per_day = floatval($_POST['price_per_day']);
    $price_per_hour = floatval($_POST['price_per_hour']);
    $extra_cat_price = floatval($_POST['extra_cat_price']);
    $description = $conn->real_escape_string($_POST['description']);
    $status = $_POST['status'] ?? 'Available';

    // Validation
    if (empty($type)) {
        $error = "กรุณาระบุประเภทห้อง";
    } elseif (empty($size)) {
        $error = "กรุณาระบุขนาดห้อง";
    } elseif ($capacity <= 0) {
        $error = "กรุณาระบุจำนวนห้องที่ถูกต้อง";
    } elseif ($max_cats <= 0) {
        $error = "กรุณาระบุจำนวนแมวสูงสุดที่ถูกต้อง";
    } elseif ($price_per_day <= 0) {
        $error = "กรุณาระบุราคาต่อวันที่ถูกต้อง";
    } else {
        if ($edit_mode) {
            // อัปเดตข้อมูล
            $sql = "UPDATE rooms SET 
                    type = '$type',
                    size = '$size',
                    capacity = $capacity,
                    max_cats = $max_cats,
                    price_per_day = $price_per_day,
                    price_per_hour = $price_per_hour,
                    extra_cat_price = $extra_cat_price,
                    description = '$description',
                    status = '$status'
                    WHERE rooms_id = $room_id";

            if ($conn->query($sql)) {
                header("Location: admin.php?tab=rooms&success=updated");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        } else {
            // เพิ่มข้อมูลใหม่
            $image = 'room-default.jpg'; // รูปภาพเริ่มต้น

            $sql = "INSERT INTO rooms (type, size, capacity, max_cats, price_per_day, price_per_hour, 
                    extra_cat_price, description, image, status) 
                    VALUES ('$type', '$size', $capacity, $max_cats, $price_per_day, $price_per_hour, 
                    $extra_cat_price, '$description', '$image', '$status')";

            if ($conn->query($sql)) {
                header("Location: admin.php?tab=rooms&success=added");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit_mode ? 'แก้ไขห้องพัก' : 'เพิ่มห้องพักใหม่' ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
    <style>
        .user-detail-container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-group small {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 0.9em;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button" style="margin-bottom: 20px;">
            <a href="admin.php?tab=rooms" class="btn">← กลับ</a>
        </div>

        <div class="content-card">
            <h2><?= $edit_mode ? '✏️ แก้ไขห้องพัก' : '➕ เพิ่มห้องพักใหม่' ?></h2>

            <?php if ($error): ?>
                <div class="alert err"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>ประเภทห้อง *</label>
                        <input type="text" name="type" placeholder="เช่น Standard, Deluxe, VIP"
                            value="<?= $edit_mode ? htmlspecialchars($room['type']) : '' ?>" required>
                        <small>ชื่อประเภทห้องพัก</small>
                    </div>

                    <div class="form-group">
                        <label>ขนาดห้อง *</label>
                        <input type="text" name="size" placeholder="เช่น 3x3 m, 4x4 m"
                            value="<?= $edit_mode ? htmlspecialchars($room['size']) : '' ?>" required>
                        <small>ขนาดห้องพัก</small>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>จำนวนห้อง *</label>
                        <input type="number" name="capacity" min="1" placeholder="5"
                            value="<?= $edit_mode ? $room['capacity'] : '' ?>" required>
                        <small>จำนวนห้องทั้งหมดที่มี</small>
                    </div>

                    <div class="form-group">
                        <label>รองรับแมวสูงสุด *</label>
                        <input type="number" name="max_cats" min="1" placeholder="2"
                            value="<?= $edit_mode ? $room['max_cats'] : '' ?>" required>
                        <small>จำนวนแมวสูงสุดต่อห้อง</small>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>ราคาต่อวัน (บาท) *</label>
                        <input type="number" step="0.01" name="price_per_day" min="0" placeholder="500.00"
                            value="<?= $edit_mode ? $room['price_per_day'] : '' ?>" required>
                        <small>ราคาต่อคืน</small>
                    </div>

                    <div class="form-group">
                        <label>ราคาต่อชั่วโมง (บาท)</label>
                        <input type="number" step="0.01" name="price_per_hour" min="0" placeholder="100.00"
                            value="<?= $edit_mode ? $room['price_per_hour'] : '' ?>">
                        <small>ราคาต่อชั่วโมง (ถ้ามี)</small>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>ราคาแมวเพิ่ม (บาท)</label>
                        <input type="number" step="0.01" name="extra_cat_price" min="0" placeholder="50.00"
                            value="<?= $edit_mode ? $room['extra_cat_price'] : '50' ?>">
                        <small>ค่าธรรมเนียมแมวเพิ่มต่อตัว</small>
                    </div>

                    <div class="form-group">
                        <label>สถานะห้อง</label>
                        <select name="status">
                            <option value="Available" <?= ($edit_mode && $room['status'] === 'Available') ? 'selected' : '' ?>>
                                พร้อมให้บริการ
                            </option>
                            <option value="Occupied" <?= ($edit_mode && $room['status'] === 'Occupied') ? 'selected' : '' ?>>
                                ไม่พร้อมให้บริการ
                            </option>
                        </select>
                        <small>สถานะปัจจุบันของห้อง</small>
                    </div>
                </div>

                <div class="form-group">
                    <label>รายละเอียดห้อง</label>
                    <textarea name="description"
                        placeholder="รายละเอียดเพิ่มเติมเกี่ยวกับห้องพัก..."><?= $edit_mode ? htmlspecialchars($room['description']) : '' ?></textarea>
                    <small>คำอธิบายเกี่ยวกับห้องพักนี้</small>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn primary">
                        <?= $edit_mode ? '💾 บันทึกการแก้ไข' : '➕ เพิ่มห้องพัก' ?>
                    </button>
                    <a href="admin.php?tab=rooms" class="btn">❌ ยกเลิก</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>