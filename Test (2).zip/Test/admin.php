<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}


$conn->query("CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL
)");

// จัดการรายจ่าย
if (isset($_POST['add_expense'])) {
    $desc = $conn->real_escape_string($_POST['description']);
    $amt = floatval($_POST['amount']);
    $date = $_POST['date'];
    $conn->query("INSERT INTO expenses (description, amount, date) VALUES ('$desc', $amt, '$date')");
    header("Location: admin.php?tab=finance");
    exit;
}

if (isset($_GET['delete_expense'])) {
    $id = intval($_GET['delete_expense']);
    $conn->query("DELETE FROM expenses WHERE id=$id");
    header("Location: admin.php?tab=finance");
    exit;
}

// สถิติรวม
$total_income = $conn->query("SELECT IFNULL(SUM(amount),0) AS total FROM payment WHERE status='Paid'")->fetch_assoc()['total'];
$total_expense_res = $conn->query("SELECT IFNULL(SUM(amount),0) AS total FROM expenses");
$total_expense = $total_expense_res->fetch_assoc()['total'];
$net_profit = $total_income - $total_expense;

$total_user = $conn->query("SELECT COUNT(*) AS cnt FROM user")->fetch_assoc()['cnt'];
$total_cats = $conn->query("SELECT COUNT(*) AS cnt FROM cats")->fetch_assoc()['cnt'];
$total_rooms = $conn->query("SELECT COUNT(*) AS cnt FROM rooms")->fetch_assoc()['cnt'];
$total_bookings = $conn->query("SELECT COUNT(*) AS cnt FROM bookings")->fetch_assoc()['cnt'];
$pending_bookings = $conn->query("SELECT COUNT(*) AS cnt FROM bookings WHERE status='Pending'")->fetch_assoc()['cnt'];

// ค้นหาลูกค้า
$search_keyword = $_GET['search'] ?? '';
$search_results = [];
if ($search_keyword) {
    $keyword = "%" . $conn->real_escape_string($search_keyword) . "%";
    $stmt = $conn->prepare("
        SELECT u.user_id, u.username, u.email, 
               IFNULL(SUM(p.amount), 0) AS total_paid,
               COUNT(DISTINCT b.booking_id) AS booking_count
        FROM user u
        LEFT JOIN bookings b ON u.user_id = b.user_id
        LEFT JOIN payment p ON b.booking_id = p.booking_id AND p.status = 'Paid'
        WHERE u.username LIKE ? OR u.email LIKE ?
        GROUP BY u.user_id
    ");
    $stmt->bind_param("ss", $keyword, $keyword);
    $stmt->execute();
    $search_results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// การจองล่าสุด
$bookings = $conn->query("
    SELECT b.booking_id, u.username, r.type AS room_type, 
           b.start_date, b.end_date, b.total_price, b.status
    FROM bookings b
    JOIN user u ON b.user_id = u.user_id
    JOIN rooms r ON b.rooms_id = r.rooms_id
    ORDER BY b.created_at DESC
    LIMIT 15
");

// ห้องทั้งหมด
$rooms = $conn->query("SELECT * FROM rooms ORDER BY rooms_id ASC");

// อาหารทั้งหมด
$foods = $conn->query("SELECT * FROM foods ORDER BY foods_id ASC");

$current_tab = $_GET['tab'] ?? 'overview';
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard - Cat Hotel</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Admin Panel</h2>
                <p><?= htmlspecialchars($_SESSION['name'] ?? 'Admin') ?></p>
            </div>

            <nav class="sidebar-nav">
                <a href="?tab=overview" class="nav-item <?= $current_tab === 'overview' ? 'active' : '' ?>">
                    <span class="nav-icon">📊</span>
                    <span>ภาพรวม</span>
                </a>
                <a href="?tab=bookings" class="nav-item <?= $current_tab === 'bookings' ? 'active' : '' ?>">
                    <span class="nav-icon">📅</span>
                    <span>การจอง</span>
                </a>
                <a href="?tab=customers" class="nav-item <?= $current_tab === 'customers' ? 'active' : '' ?>">
                    <span class="nav-icon">👥</span>
                    <span>ลูกค้า</span>
                </a>
                <a href="?tab=rooms" class="nav-item <?= $current_tab === 'rooms' ? 'active' : '' ?>">
                    <span class="nav-icon">🏠</span>
                    <span>จัดการห้องพัก</span>
                </a>
                <a href="?tab=foods" class="nav-item <?= $current_tab === 'foods' ? 'active' : '' ?>">
                    <span class="nav-icon">🍽️</span>
                    <span>จัดการอาหาร</span>
                </a>
                <a href="?tab=finance" class="nav-item <?= $current_tab === 'finance' ? 'active' : '' ?>">
                    <span class="nav-icon">💰</span>
                    <span>การเงิน</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                <a href="?tab=overview" class="btn btn-sm">หน้าหลัก</a>
                <a href="logout.php" class="btn btn-sm danger">ออกจากระบบ</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="admin-main">
            <?php if ($current_tab === 'overview'): ?>
                <!-- Overview Tab -->
                <div class="admin-header">
                    <h1>ภาพรวมระบบ</h1>
                </div>

                <div class="stats-grid">
                    <div class="stat-card green">
                        <div class="stat-icon">💵</div>
                        <div class="stat-info">
                            <div class="stat-label">รายรับทั้งหมด</div>
                            <div class="stat-value"><?= number_format($total_income, 2) ?> ฿</div>
                        </div>
                    </div>

                    <div class="stat-card red">
                        <div class="stat-icon">💸</div>
                        <div class="stat-info">
                            <div class="stat-label">รายจ่ายทั้งหมด</div>
                            <div class="stat-value"><?= number_format($total_expense, 2) ?> ฿</div>
                        </div>
                    </div>

                    <div class="stat-card blue">
                        <div class="stat-icon">💰</div>
                        <div class="stat-info">
                            <div class="stat-label">กำไรสุทธิ</div>
                            <div class="stat-value"><?= number_format($net_profit, 2) ?> ฿</div>
                        </div>
                    </div>

                    <div class="stat-card purple">
                        <div class="stat-icon">👥</div>
                        <div class="stat-info">
                            <div class="stat-label">ลูกค้าทั้งหมด</div>
                            <div class="stat-value"><?= $total_user ?></div>
                        </div>
                    </div>

                    <div class="stat-card orange">
                        <div class="stat-icon">📊</div>
                        <div class="stat-info">
                            <div class="stat-label">การจองทั้งหมด</div>
                            <div class="stat-value"><?= $total_bookings ?></div>
                        </div>
                    </div>

                    <div class="stat-card yellow">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-info">
                            <div class="stat-label">รอชำระเงิน</div>
                            <div class="stat-value"><?= $pending_bookings ?></div>
                        </div>
                    </div>

                    <div class="stat-card pink">
                        <div class="stat-icon">🏠</div>
                        <div class="stat-info">
                            <div class="stat-label">ห้องทั้งหมด</div>
                            <div class="stat-value"><?= $total_rooms ?></div>
                        </div>
                    </div>

                    <div class="stat-card teal">
                        <div class="stat-icon">🐱</div>
                        <div class="stat-info">
                            <div class="stat-label">แมวทั้งหมด</div>
                            <div class="stat-value"><?= $total_cats ?></div>
                        </div>
                    </div>
                </div>

                <div class="content-card">
                    <h3>การจองล่าสุด</h3>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ลูกค้า</th>
                                    <th>ห้อง</th>
                                    <th>เริ่ม</th>
                                    <th>สิ้นสุด</th>
                                    <th>ราคา</th>
                                    <th>สถานะ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $bookings->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?= $row['booking_id'] ?></td>
                                        <td><?= htmlspecialchars($row['username']) ?></td>
                                        <td><?= htmlspecialchars($row['room_type']) ?></td>
                                        <td><?= date('d/m/Y', strtotime($row['start_date'])) ?></td>
                                        <td><?= date('d/m/Y', strtotime($row['end_date'])) ?></td>
                                        <td><?= number_format($row['total_price'], 2) ?></td>
                                        <td><span
                                                class="badge badge-<?= strtolower($row['status']) ?>"><?= $row['status'] ?></span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($current_tab === 'customers'): ?>
                <!-- Customers Tab -->
                <div class="admin-header">
                    <h1>จัดการลูกค้า</h1>
                </div>

                <div class="content-card">
                    <form method="GET" class="search-form">
                        <input type="hidden" name="tab" value="customers">
                        <input type="text" name="search" placeholder="ค้นหาชื่อหรืออีเมลลูกค้า"
                            value="<?= htmlspecialchars($search_keyword) ?>">
                        <button type="submit" class="btn primary">ค้นหา</button>
                    </form>

                    <?php if ($search_keyword && count($search_results) > 0): ?>
                        <h3>ผลการค้นหา: <?= count($search_results) ?> รายการ</h3>
                        <div class="table-responsive">
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>ชื่อ</th>
                                        <th>อีเมล</th>
                                        <th>จำนวนการจอง</th>
                                        <th>ยอดชำระรวม</th>
                                        <th>การจัดการ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($search_results as $user): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($user['username']) ?></td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td><?= $user['booking_count'] ?></td>
                                            <td><?= number_format($user['total_paid'], 2) ?> ฿</td>
                                            <td>
                                                <a href="user_detail.php?user_id=<?= $user['user_id'] ?>"
                                                    class="btn btn-sm info">ดูรายละเอียด</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif ($search_keyword): ?>
                        <p class="text-muted">ไม่พบผลการค้นหา</p>
                    <?php endif; ?>
                </div>

            <?php elseif ($current_tab === 'rooms'): ?>
                <!-- Rooms Tab -->
                <div class="admin-header">
                    <h1>จัดการห้องพัก</h1>
                    <a href="room_add.php" class="btn primary">เพิ่มห้องใหม่</a>
                </div>

                <div class="content-card">
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ประเภท</th>
                                    <th>ขนาด</th>
                                    <th>จำนวนห้อง</th>
                                    <th>แมวสูงสุด</th>
                                    <th>ราคา/วัน</th>
                                    <th>ราคา/ชม.</th>
                                    <th>การจัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($room = $rooms->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?= $room['rooms_id'] ?></td>
                                        <td><?= htmlspecialchars($room['type']) ?></td>
                                        <td><?= htmlspecialchars($room['size']) ?></td>
                                        <td><?= $room['capacity'] ?></td>
                                        <td><?= $room['max_cats'] ?></td>
                                        <td><?= number_format($room['price_per_day'], 2) ?> ฿</td>
                                        <td><?= number_format($room['price_per_hour'], 2) ?> ฿</td>
                                        <td>
                                            <a href="room_edit.php?id=<?= $room['rooms_id'] ?>"
                                                class="btn btn-sm info">แก้ไข</a>
                                            <a href="room_delete.php?id=<?= $room['rooms_id'] ?>" class="btn btn-sm danger"
                                                onclick="return confirm('ลบห้องนี้?')">ลบ</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($current_tab === 'bookings'): ?>
                <!-- Bookings Tab -->
                <div class="admin-header">
                    <h1>จัดการการจอง</h1>
                </div>

                <?php
                // Filter
                $status_filter = $_GET['status'] ?? 'all';
                $search = $_GET['search'] ?? '';

                // Build query
                $where = [];
                if ($status_filter !== 'all') {
                    $where[] = "b.status = '" . $conn->real_escape_string($status_filter) . "'";
                }
                if ($search) {
                    $search_safe = $conn->real_escape_string($search);
                    $where[] = "(u.username LIKE '%$search_safe%' OR b.booking_id = '$search_safe')";
                }

                $where_clause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

                $bookings_query = "
        SELECT b.booking_id, u.username, u.email, r.type AS room_type,
               b.start_date, b.end_date, b.booking_type, b.total_price, b.status,
               b.created_at,
               COUNT(DISTINCT bc.cat_id) AS cat_count
        FROM bookings b
        JOIN user u ON b.user_id = u.user_id
        JOIN rooms r ON b.rooms_id = r.rooms_id
        LEFT JOIN bookings_cats bc ON b.booking_id = bc.booking_id
        $where_clause
        GROUP BY b.booking_id
        ORDER BY b.created_at DESC
        LIMIT 50
    ";

                $all_bookings = $conn->query($bookings_query);

                // นับจำนวนแต่ละสถานะ
                $status_counts = [
                    'all' => $conn->query("SELECT COUNT(*) as cnt FROM bookings")->fetch_assoc()['cnt'],
                    'Pending' => $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='Pending'")->fetch_assoc()['cnt'],
                    'Confirmed' => $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='Confirmed'")->fetch_assoc()['cnt'],
                    'Occupied' => $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='Occupied'")->fetch_assoc()['cnt'],
                    'Completed' => $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='Completed'")->fetch_assoc()['cnt'],
                    'Cancelled' => $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='Cancelled'")->fetch_assoc()['cnt']
                ];
                ?>

                <div class="content-card">
                    <!-- Filter Tabs -->
                    <div class="filter-tabs">
                        <a href="?tab=bookings&status=all"
                            class="filter-tab <?= $status_filter === 'all' ? 'active' : '' ?>">
                            ทั้งหมด (<?= $status_counts['all'] ?>)
                        </a>
                        <a href="?tab=bookings&status=Pending"
                            class="filter-tab <?= $status_filter === 'Pending' ? 'active' : '' ?>">
                            รอชำระ (<?= $status_counts['Pending'] ?>)
                        </a>
                        <a href="?tab=bookings&status=Confirmed"
                            class="filter-tab <?= $status_filter === 'Confirmed' ? 'active' : '' ?>">
                            ยืนยันแล้ว (<?= $status_counts['Confirmed'] ?>)
                        </a>
                        <a href="?tab=bookings&status=Occupied"
                            class="filter-tab <?= $status_filter === 'Occupied' ? 'active' : '' ?>">
                            กำลังพัก (<?= $status_counts['Occupied'] ?>)
                        </a>
                        <a href="?tab=bookings&status=Completed"
                            class="filter-tab <?= $status_filter === 'Completed' ? 'active' : '' ?>">
                            เสร็จสิ้น (<?= $status_counts['Completed'] ?>)
                        </a>
                        <a href="?tab=bookings&status=Cancelled"
                            class="filter-tab <?= $status_filter === 'Cancelled' ? 'active' : '' ?>">
                            ยกเลิก (<?= $status_counts['Cancelled'] ?>)
                        </a>
                    </div>

                    <!-- Search Bar -->
                    <form method="GET" class="search-form" style="margin-top: 20px;">
                        <input type="hidden" name="tab" value="bookings">
                        <input type="hidden" name="status" value="<?= $status_filter ?>">
                        <input type="text" name="search" placeholder="ค้นหา Booking ID หรือชื่อลูกค้า"
                            value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn primary">ค้นหา</button>
                        <?php if ($search): ?>
                            <a href="?tab=bookings&status=<?= $status_filter ?>" class="btn">ล้างการค้นหา</a>
                        <?php endif; ?>
                    </form>

                    <!-- Bookings Table -->
                    <div class="table-responsive" style="margin-top: 20px;">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ลูกค้า</th>
                                    <th>ห้อง</th>
                                    <th>แมว</th>
                                    <th>เริ่ม - สิ้นสุด</th>
                                    <th>ราคา</th>
                                    <th>สถานะ</th>
                                    <th>การจัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($all_bookings && $all_bookings->num_rows > 0): ?>
                                    <?php while ($booking = $all_bookings->fetch_assoc()): ?>
                                        <tr>
                                            <td><strong>#<?= $booking['booking_id'] ?></strong></td>
                                            <td>
                                                <?= htmlspecialchars($booking['username']) ?><br>
                                                <small class="muted"><?= htmlspecialchars($booking['email']) ?></small>
                                            </td>
                                            <td><?= htmlspecialchars($booking['room_type']) ?></td>
                                            <td><?= $booking['cat_count'] ?> ตัว</td>
                                            <td>
                                                <?= date('d/m/Y', strtotime($booking['start_date'])) ?><br>
                                                <small class="muted">ถึง
                                                    <?= date('d/m/Y', strtotime($booking['end_date'])) ?></small>
                                            </td>
                                            <td><?= number_format($booking['total_price'], 2) ?> ฿</td>
                                            <td>
                                                <span class="badge badge-<?= strtolower($booking['status']) ?>">
                                                    <?= $booking['status'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <!-- ปุ่มดูรายละเอียดการจองและข้อมูลลูกค้า -->
                                                <a href="booking_detail.php?id=<?= $booking['booking_id'] ?>"
                                                    class="btn btn-sm info">ดู</a>

                                                <!-- ปุ่มเช็คอิน - แสดงเมื่อสถานะเป็น Confirmed -->
                                                <?php if ($booking['status'] === 'Confirmed'): ?>
                                                    <a href="booking_update.php?id=<?= $booking['booking_id'] ?>&status=Occupied"
                                                        class="btn btn-sm primary"
                                                        onclick="return confirm('เปลี่ยนสถานะเป็น กำลังพัก?')">
                                                        เช็คอิน
                                                    </a>
                                                <?php endif; ?>

                                                <!-- ปุ่มเช็คเอาท์ - แสดงเมื่อสถานะเป็น Occupied -->
                                                <?php if ($booking['status'] === 'Occupied'): ?>
                                                    <a href="booking_update.php?id=<?= $booking['booking_id'] ?>&status=Completed"
                                                        class="btn btn-sm success"
                                                        onclick="return confirm('เปลี่ยนสถานะเป็น เสร็จสิ้น?')">
                                                        เช็คเอาท์
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-muted" style="text-align: center; padding: 40px;">
                                            ไม่พบการจอง
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($current_tab === 'foods'): ?>
                <!-- Foods Tab -->
                <div class="admin-header">
                    <h1>จัดการอาหาร</h1>
                    <a href="food_add.php" class="btn primary">เพิ่มอาหารใหม่</a>
                </div>

                <div class="content-card">
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ชื่ออาหาร</th>
                                    <th>ราคา/วัน</th>
                                    <th>การจัดการ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($food = $foods->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?= $food['foods_id'] ?></td>
                                        <td><?= htmlspecialchars($food['foods_name']) ?></td>
                                        <td><?= number_format($food['price'], 2) ?> ฿</td>
                                        <td>
                                            <a href="food_add.php?id=<?= $food['foods_id'] ?>" class="btn btn-sm info">แก้ไข</a>
                                            <a href="food_delete.php?id=<?= $food['foods_id'] ?>" class="btn btn-sm danger"
                                                onclick="return confirm('ลบอาหารนี้?')">ลบ</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($current_tab === 'finance'): ?>
                <!-- Finance Tab -->
                <div class="admin-header">
                    <h1>การเงิน</h1>
                </div>

                <div class="content-card">
                    <h3>เพิ่มรายการรายจ่าย</h3>
                    <form method="POST" class="finance-form">
                        <div class="form-row">
                            <input type="text" name="description" placeholder="รายการ" required>
                            <input type="number" step="0.01" name="amount" placeholder="จำนวนเงิน" required>
                            <input type="date" name="date" required>
                            <button type="submit" name="add_expense" class="btn danger">เพิ่ม</button>
                        </div>
                    </form>

                    <h3>รายการรายจ่ายย้อนหลัง</h3>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>รายการ</th>
                                    <th>จำนวน</th>
                                    <th>วันที่</th>
                                    <th>ลบ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $expenses = $conn->query("SELECT * FROM expenses ORDER BY date DESC");
                                $i = 1;
                                while ($row = $expenses->fetch_assoc()):
                                    ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><?= htmlspecialchars($row['description']) ?></td>
                                        <td><?= number_format($row['amount'], 2) ?> ฿</td>
                                        <td><?= date('d/m/Y', strtotime($row['date'])) ?></td>
                                        <td>
                                            <a href="?tab=finance&delete_expense=<?= $row['id'] ?>" class="btn btn-sm danger"
                                                onclick="return confirm('ลบรายการนี้?')">ลบ</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php endif; ?>
        </div>
    </div>
</body>

</html>