<?php
session_start();
include("db_connect.php");

// ตรวจสอบสิทธิ์ admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $room_id = intval($_GET['id']);
    
    // ตรวจสอบว่ามีการจองห้องนี้อยู่หรือไม่
    $check = $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE rooms_id = $room_id");
    $result = $check->fetch_assoc();
    
    if ($result['cnt'] > 0) {
        // มีการจองอยู่ ไม่สามารถลบได้
        $_SESSION['room_delete_error'] = 'มีการจองห้องนี้อยู่ ไม่สามารถลบได้';
        header("Location: admin.php?tab=rooms&error=has_bookings");
        exit();
    }
    
    // ลบห้อง
    if ($conn->query("DELETE FROM rooms WHERE rooms_id = $room_id")) {
        $_SESSION['room_delete_success'] = 'ลบห้องพักสำเร็จ';
        header("Location: admin.php?tab=rooms&success=deleted");
        exit();
    } else {
        $_SESSION['room_delete_error'] = 'เกิดข้อผิดพลาด: ' . $conn->error;
        header("Location: admin.php?tab=rooms&error=delete_failed");
        exit();
    }
} else {
    header("Location: admin.php?tab=rooms");
    exit();
}
?>