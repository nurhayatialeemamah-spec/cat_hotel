<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "cat_hotel";

// ขั้นตอนที่ 1: เชื่อมต่อ MySQL โดยยังไม่เลือกฐานข้อมูล
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ขั้นตอนที่ 2: ถ้าไม่มี database ให้สร้างอัตโนมัติ
$sql = "CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
if (!$conn->query($sql)) {
    die("Error creating database: " . $conn->error);
}

// ขั้นตอนที่ 3: เลือกใช้ฐานข้อมูลนี้
$conn->select_db($database);

// ตั้ง charset ให้รองรับภาษาไทย
$conn->set_charset("utf8mb4");
?>
