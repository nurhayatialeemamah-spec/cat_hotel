<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$booking_id = intval($_GET['id'] ?? 0);
$new_status = $_GET['status'] ?? '';

$allowed_statuses = ['Pending', 'Confirmed', 'Occupied', 'Completed', 'Cancelled'];

if ($booking_id && in_array($new_status, $allowed_statuses)) {
    $stmt = $conn->prepare("UPDATE bookings SET status=? WHERE booking_id=?");
    $stmt->bind_param("si", $new_status, $booking_id);
    $stmt->execute();
    
    header("Location: admin.php?tab=bookings&success=status_updated");
} else {
    header("Location: admin.php?tab=bookings&error=invalid");
}
exit();
?>