<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$food_id = intval($_GET['id'] ?? 0);
if (!$food_id) {
    header("Location: admin.php?tab=foods");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM foods WHERE foods_id=?");
$stmt->bind_param("i", $food_id);
$stmt->execute();
$food = $stmt->get_result()->fetch_assoc();

if (!$food) {
    header("Location: admin.php?tab=foods");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['foods_name']);
    $price = floatval($_POST['price']);

    if (empty($name)) {
        $error = "กรุณาระบุชื่ออาหาร";
    } elseif ($price <= 0) {
        $error = "กรุณาระบุราคาที่ถูกต้อง";
    } else {
        $conn->query("UPDATE foods SET foods_name='$name', price=$price WHERE foods_id=$food_id");
        header("Location: admin.php?tab=foods&success=updated");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แก้ไขอาหาร</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button">
            <a href="admin.php?tab=foods" class="btn">← กลับ</a>
        </div>

        <div class="content-card">
            <h2>แก้ไขอาหาร</h2>

            <?php if ($error): ?>
                <div class="alert err"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <label>ชื่ออาหาร *</label>
                <input type="text" name="foods_name" value="<?= htmlspecialchars($food['foods_name']) ?>" required>

                <label>ราคาต่อวัน (บาท) *</label>
                <input type="number" step="0.01" name="price" value="<?= $food['price'] ?>" min="0" required>

                <div style="margin-top: 20px;">
                    <button type="submit" class="btn primary">บันทึกการแก้ไข</button>
                    <a href="admin.php?tab=foods" class="btn">ยกเลิก</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>