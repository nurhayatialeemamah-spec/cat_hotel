<?php
session_start();
require_once __DIR__ . '/db_connect.php';

if (method_exists($conn, 'set_charset')) {
  $conn->set_charset('utf8mb4');
}
function h($s)
{
  return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

// คำนวณห้องที่ว่างอย่างถูกต้อง
$sql = "SELECT r.rooms_id, r.type, r.size, r.price_per_day, r.status, r.capacity, r.max_cats,
        COALESCE(b.used_rooms, 0) AS used_rooms,
        (r.capacity - COALESCE(b.used_rooms, 0)) AS available_rooms
        FROM rooms r
        LEFT JOIN (
          SELECT rooms_id, COUNT(*) AS used_rooms
          FROM bookings
          WHERE status IN ('Pending','Confirmed','Paid','Occupied')
            AND end_date > NOW()
            AND start_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)
          GROUP BY rooms_id
        ) b ON r.rooms_id = b.rooms_id
        WHERE (r.capacity - COALESCE(b.used_rooms, 0)) > 0
        ORDER BY r.price_per_day ASC, r.rooms_id ASC
        LIMIT 4";

$rooms_result = $conn->query($sql);

$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['name'] ?? '';
$role = $_SESSION['role'] ?? null;

function roomImagePath($roomId)
{
  $base = 'assets/images/';
  $candidates = [
    $base . "room{$roomId}.jpg",
    $base . "room{$roomId}.png",
    $base . "room{$roomId}.jpg",
    $base . 'room-default.jpg',
  ];
  foreach ($candidates as $path) {
    if (is_file(__DIR__ . '/' . $path))
      return $path;
  }
  return $base . 'room-default.jpg';
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <title>Cat Hotel - โรงแรมแมวคุณภาพ</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/index_style.css">
  <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
    rel="stylesheet">

  <style>
    * {
      font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
    }
  </style>
</head>

<body>
  <div class="container section">
    <div class="topbar">
      <h1 class="section-title" style="margin-right:auto">🐾 Cat Hotel</h1>
      <?php if ($user_id): ?>
        <span>สวัสดี <?= h($user_name) ?></span>
        <a class="btn" href="logout.php">ออกจากระบบ</a>
        <?php if ($role === 'admin' || $role === 'staff'): ?>
          <a class="btn" href="admin.php">แดชบอร์ด</a>
        <?php else: ?>
          <a class="btn" href="dashboard.php">แดชบอร์ด</a>
        <?php endif; ?>
      <?php else: ?>
        <a class="btn" href="login.php">เข้าสู่ระบบ</a>
        <a class="btn primary" href="register.php">สมัครสมาชิก</a>
      <?php endif; ?>
    </div>

    <div class="hero-banner">
      <h1>ยินดีต้อนรับสู่ Cat Hotel</h1>
      <p>บ้านพักหรูสำหรับแมวของคุณ พร้อมสิ่งอำนวยความสะดวกครบครัน</p>
      <a href="rooms.php" class="btn-hero">ดูห้องพักทั้งหมด</a>
    </div>

    <h2 style="margin-top: 40px;">แพ็กเกจห้องพักแนะนำ</h2>
    <?php if (!$rooms_result || $rooms_result->num_rows === 0): ?>
      <div class="empty-state">
        <div class="empty-icon">🏠</div>
        <p>ขณะนี้ห้องพักเต็มหมดแล้ว</p>
        <a href="rooms.php" class="btn">ดูห้องพักทั้งหมด</a>
      </div>
    <?php else: ?>
      <div class="rooms">
        <?php while ($row = $rooms_result->fetch_assoc()): ?>
          <?php
          $roomId = (int) $row['rooms_id'];
          $type = (string) $row['type'];
          $sizeNote = (string) $row['size'];
          $perNight = (float) $row['price_per_day'];
          $capacity = (int) $row['capacity'];
          $maxCats = (int) $row['max_cats'];
          $available = (int) $row['available_rooms'];
          $used = (int) $row['used_rooms'];
          $img = roomImagePath($roomId);

          // กำหนดสถานะห้อง
          if ($available <= 0) {
            $statusClass = 'full';
            $statusText = 'เต็มแล้ว';
          } elseif ($available <= 2) {
            $statusClass = 'limited';
            $statusText = "เหลืออีก {$available} ห้อง";
          } else {
            $statusClass = 'available';
            $statusText = "ว่าง {$available}/{$capacity} ห้อง";
          }
          ?>
          <div class="room-card">
            <div class="room-image-wrapper">
              <img src="<?= h($img) ?>" alt="<?= h($type) ?>"
                onerror="this.onerror=null;this.src='assets/images/room-default.jpg'">
              <div class="room-status <?= $statusClass ?>">
                <?= $statusText ?>
              </div>
            </div>
            <div class="content">
              <h3><?= h($type) ?> Room</h3>
              <div class="room-info">
                <div class="info-item">
                  <span class="icon">📐</span>
                  <span>ขนาด: <?= h($sizeNote) ?></span>
                </div>
                <div class="info-item">
                  <span class="icon">🐱</span>
                  <span>รองรับ: <?= $maxCats ?> ตัว</span>
                </div>
              </div>
              <div class="price">
                <span class="price-amount"><?= number_format($perNight, 0) ?></span>
                <span class="price-unit">บาท/คืน</span>
              </div>
              <div class="room-actions">
                <?php if ($user_id): ?>
                  <?php if ($available > 0): ?>
                    <a class="btn primary full-width" href="rooms.php?room_id=<?= $roomId ?>">จองเลย</a>
                  <?php else: ?>
                    <button class="btn full-width" disabled>ห้องเต็ม</button>
                  <?php endif; ?>
                <?php else: ?>
                  <a class="btn full-width" href="login.php">เข้าสู่ระบบเพื่อจอง</a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>

      <div style="text-align: center; margin-top: 30px;">
        <a href="rooms.php" class="btn-view-all">ดูห้องพักทั้งหมด →</a>
      </div>
    <?php endif; ?>

    <section id="pricing" class="pricing-section">
      <h2 class="section-title">อัตราการบริการ & สิ่งอำนวยความสะดวก</h2>
      <div class="pricing-grid">
        <div class="pricing-box">
          <div class="pricing-icon">💰</div>
          <h5>แพ็กเกจและราคา</h5>
          <ul class="pricing-list">
            <li>Standard Room – 500 ฿ / คืน ( 1-2 ตัว )</li>
            <li>Deluxe Room – 800 ฿ / คืน ( 1-3 ตัว )</li>
            <li>Suite Room – 1,200 ฿ / คืน ( 1-4 ตัว )</li>
            <li>VIP Plus – 2,000 ฿ / คืน ( 1-5ตัว )</li>
          </ul>
        </div>
        <div class="pricing-box">
          <div class="pricing-icon">✨</div>
          <h5>สิ่งอำนวยความสะดวก</h5>
          <ul class="pricing-list">
            <li>ชามอาหาร / ชามน้ำ (แยกโซนเมื่อจำเป็น)</li>
            <li>กระบะทราย + ที่ตักส่วนตัว (ทรายเบนโทไนท์ฟรี)</li>
            <li>กล่องนอน • ชั้นปีนป่าย • แผ่นลับเล็บ</li>
            <li>ห้องน้ำแมวส่วนตัว (VIP)</li>
            <li>CCTV + พี่เลี้ยงดูแล 24 ชม.</li>
            <li>อัปเดตรูปภาพรายวัน</li>
          </ul>
        </div>
      </div>
    </section>

    <section id="contact" class="contact-section">
      <h2>ติดต่อเรา</h2>
      <div class="contact-card">
        <div class="contact-item">
          <span class="contact-icon">📞</span>
          <div>
            <strong>โทรศัพท์</strong>
            <p>098-888-8888</p>
          </div>
        </div>
        <div class="contact-item">
          <span class="contact-icon">📍</span>
          <div>
            <strong>ที่อยู่</strong>
            <p>181 หมู่ที่ 6 ถนนเจริญประดิษฐ์ ตำบลรูสะมิแล อำเภอเมือง จังหวัดปัตตานี 94000</p>
          </div>
        </div>
        <div class="contact-item">
          <span class="contact-icon">💬</span>
          <div>
            <strong>โซเชียลมีเดีย</strong>
            <p>Facebook • Instagram • TikTok</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</body>

</html>