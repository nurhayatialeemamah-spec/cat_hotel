<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = intval($_GET['user_id'] ?? 0);
if (!$user_id) {
    echo "ไม่พบลูกค้า";
    exit;
}

// ดึงข้อมูลลูกค้า
$stmt = $conn->prepare("SELECT * FROM user WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_detail = $stmt->get_result()->fetch_assoc();

if (!$user_detail) {
    echo "ไม่พบข้อมูลลูกค้า";
    exit;
}

// ดึงข้อมูลแมวของลูกค้า
$cats_stmt = $conn->prepare("SELECT * FROM cats WHERE user_id=?");
$cats_stmt->bind_param("i", $user_id);
$cats_stmt->execute();
$cats = $cats_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ดึงรายการจองพร้อมรายละเอียด
$bookings_stmt = $conn->prepare("
    SELECT b.booking_id, r.type AS room_type, r.rooms_id,
           b.start_date, b.end_date, b.booking_type, b.total_price, b.status,
           IFNULL(SUM(p.amount), 0) AS paid_amount,
           COUNT(DISTINCT bc.cat_id) AS cat_count
    FROM bookings b
    JOIN rooms r ON b.rooms_id = r.rooms_id
    LEFT JOIN payment p ON b.booking_id = p.booking_id AND p.status='Paid'
    LEFT JOIN bookings_cats bc ON b.booking_id = bc.booking_id
    WHERE b.user_id=?
    GROUP BY b.booking_id
    ORDER BY b.start_date DESC
");
$bookings_stmt->bind_param("i", $user_id);
$bookings_stmt->execute();
$bookings = $bookings_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// คำนวณสถิติ
$total_bookings = count($bookings);
$total_spent = array_sum(array_column($bookings, 'paid_amount'));
$completed_bookings = count(array_filter($bookings, fn($b) => $b['status'] === 'Completed'));
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายละเอียดลูกค้า - <?= htmlspecialchars($user_detail['username']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
    <style>
        .user-detail-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 32px;
        }

        .back-button {
            margin-bottom: 24px;
        }

        .user-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: white;
            padding: 32px;
            border-radius: 16px;
            margin-bottom: 32px;
        }

        .user-header h1 {
            margin: 0 0 8px;
            font-size: 32px;
        }

        .user-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .info-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }

        .info-label {
            font-size: 13px;
            color: var(--muted);
            margin-bottom: 4px;
        }

        .info-value {
            font-size: 18px;
            font-weight: 600;
            color: var(--text);
        }

        .cats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }

        .cat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
        }

        .cat-card h4 {
            margin: 0 0 12px;
            color: var(--primary);
        }

        .cat-detail {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        .cat-detail:last-child {
            border-bottom: none;
        }

        .booking-timeline {
            position: relative;
            padding-left: 32px;
        }

        .booking-item {
            position: relative;
            padding: 20px;
            margin-bottom: 16px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
        }

        .booking-item::before {
            content: '';
            position: absolute;
            left: -26px;
            top: 24px;
            width: 12px;
            height: 12px;
            background: var(--primary);
            border-radius: 50%;
        }

        .booking-item::after {
            content: '';
            position: absolute;
            left: -21px;
            top: 36px;
            width: 2px;
            height: calc(100% + 16px);
            background: var(--border);
        }

        .booking-item:last-child::after {
            display: none;
        }

        .booking-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .booking-id {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary);
        }

        .booking-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
            margin-top: 12px;
        }
    </style>
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button">
            <a href="admin.php?tab=customers" class="btn">← กลับไปหน้า Admin</a>
        </div>

        <div class="user-header">
            <h1>👤 <?= htmlspecialchars($user_detail['username']) ?></h1>
            <p><?= htmlspecialchars($user_detail['email']) ?></p>
        </div>

        <!-- Stats Cards -->
        <div class="user-info-grid">
            <div class="info-card">
                <div class="info-label">เบอร์โทรศัพท์</div>
                <div class="info-value"><?= htmlspecialchars($user_detail['phone'] ?? '-') ?></div>
            </div>

            <div class="info-card">
                <div class="info-label">บทบาท</div>
                <div class="info-value"><?= htmlspecialchars($user_detail['role'] ?? 'user') ?></div>
            </div>

            <div class="info-card">
                <div class="info-label">จำนวนการจอง</div>
                <div class="info-value"><?= $total_bookings ?> ครั้ง</div>
            </div>

            <div class="info-card">
                <div class="info-label">ยอดใช้จ่ายทั้งหมด</div>
                <div class="info-value"><?= number_format($total_spent, 2) ?> ฿</div>
            </div>
        </div>

        <!-- Address -->
        <?php if (!empty($user_detail['address'])): ?>
            <div class="content-card">
                <h3>ที่อยู่</h3>
                <p><?= nl2br(htmlspecialchars($user_detail['address'])) ?></p>
            </div>
        <?php endif; ?>

        <!-- Cats Section -->
        <div class="content-card">
            <h3>🐱 แมวของลูกค้า (<?= count($cats) ?> ตัว)</h3>

            <?php if (count($cats) > 0): ?>
                <div class="cats-grid">
                    <?php foreach ($cats as $cat): ?>
                        <div class="cat-card">
                            <h4><?= htmlspecialchars($cat['name']) ?></h4>
                            <div class="cat-detail">
                                <span>เพศ:</span>
                                <strong><?= $cat['gender'] === 'Male' ? 'ผู้' : 'เมีย' ?></strong>
                            </div>
                            <div class="cat-detail">
                                <span>อายุ:</span>
                                <strong><?= $cat['age'] ?> ปี</strong>
                            </div>
                            <div class="cat-detail">
                                <span>พันธุ์:</span>
                                <strong><?= htmlspecialchars($cat['breed']) ?></strong>
                            </div>
                            <div class="cat-detail">
                                <span>น้ำหนัก:</span>
                                <strong><?= $cat['weight'] ?> กก.</strong>
                            </div>
                            <?php if ($cat['disease']): ?>
                                <div class="cat-detail">
                                    <span>โรคประจำตัว:</span>
                                    <strong><?= htmlspecialchars($cat['disease']) ?></strong>
                                </div>
                            <?php endif; ?>
                            <?php if ($cat['allergy']): ?>
                                <div class="cat-detail">
                                    <span>แพ้อาหาร:</span>
                                    <strong><?= htmlspecialchars($cat['allergy']) ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted">ยังไม่มีข้อมูลแมว</p>
            <?php endif; ?>
        </div>

        <!-- Bookings Timeline -->
        <div class="content-card">
            <h3>📅 ประวัติการจอง (<?= $total_bookings ?> ครั้ง)</h3>

            <?php if (count($bookings) > 0): ?>
                <div class="booking-timeline">
                    <?php foreach ($bookings as $booking):
                        $num_days = max(1, ceil((strtotime($booking['end_date']) - strtotime($booking['start_date'])) / 86400));
                        ?>
                        <div class="booking-item">
                            <div class="booking-header">
                                <span class="booking-id">Booking #<?= $booking['booking_id'] ?></span>
                                <span class="badge badge-<?= strtolower($booking['status']) ?>">
                                    <?= $booking['status'] ?>
                                </span>
                            </div>

                            <div class="booking-details">
                                <div>
                                    <div class="info-label">ห้อง</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= htmlspecialchars($booking['room_type']) ?> Room
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">วันที่เข้าพัก</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= date('d/m/Y', strtotime($booking['start_date'])) ?>
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">วันที่คืนห้อง</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= date('d/m/Y', strtotime($booking['end_date'])) ?>
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">ระยะเวลา</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= $num_days ?> วัน
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">จำนวนแมว</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= $booking['cat_count'] ?> ตัว
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">ประเภทการจอง</div>
                                    <div class="info-value" style="font-size: 16px;">
                                        <?= $booking['booking_type'] === 'Daily' ? 'รายวัน' : 'รายชั่วโมง' ?>
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">ราคารวม</div>
                                    <div class="info-value" style="font-size: 16px; color: var(--primary);">
                                        <?= number_format($booking['total_price'], 2) ?> ฿
                                    </div>
                                </div>

                                <div>
                                    <div class="info-label">ยอดชำระแล้ว</div>
                                    <div class="info-value" style="font-size: 16px; color: #10b981;">
                                        <?= number_format($booking['paid_amount'], 2) ?> ฿
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted">ยังไม่มีการจอง</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>