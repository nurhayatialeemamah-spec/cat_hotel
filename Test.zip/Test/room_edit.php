<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$room_id = intval($_GET['id'] ?? 0);
if (!$room_id) {
    header("Location: admin.php?tab=rooms");
    exit();
}

// ดึงข้อมูลห้อง
$stmt = $conn->prepare("SELECT * FROM rooms WHERE rooms_id=?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

if (!$room) {
    header("Location: admin.php?tab=rooms");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $conn->real_escape_string($_POST['type']);
    $size = $conn->real_escape_string($_POST['size']);
    $capacity = intval($_POST['capacity']);
    $max_cats = intval($_POST['max_cats']);
    $price_per_hour = floatval($_POST['price_per_hour']);
    $price_per_day = floatval($_POST['price_per_day']);
    $description = $conn->real_escape_string($_POST['description']);

    if (empty($type) || $capacity <= 0 || $max_cats <= 0) {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
    } else {
        $sql = "UPDATE rooms SET 
                type='$type', size='$size', capacity=$capacity, max_cats=$max_cats,
                price_per_hour=$price_per_hour, price_per_day=$price_per_day, description='$description'
                WHERE rooms_id=$room_id";

        if ($conn->query($sql)) {
            header("Location: admin.php?tab=rooms&success=updated");
            exit();
        } else {
            $error = "เกิดข้อผิดพลาด: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แก้ไขห้องพัก</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button">
            <a href="admin.php?tab=rooms" class="btn">← กลับ</a>
        </div>

        <div class="content-card">
            <h2>แก้ไขห้องพัก #<?= $room_id ?></h2>

            <?php if ($error): ?>
                <div class="alert err"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <label>ประเภทห้อง *</label>
                <input type="text" name="type" value="<?= htmlspecialchars($room['type']) ?>" required>

                <label>ขนาดห้อง</label>
                <input type="text" name="size" value="<?= htmlspecialchars($room['size']) ?>">

                <label>จำนวนห้อง (Capacity) *</label>
                <input type="number" name="capacity" value="<?= $room['capacity'] ?>" min="1" required>

                <label>รองรับแมวสูงสุด (ต่อห้อง) *</label>
                <input type="number" name="max_cats" value="<?= $room['max_cats'] ?>" min="1" required>

                <label>ราคาต่อชั่วโมง (บาท) *</label>
                <input type="number" step="0.01" name="price_per_hour" value="<?= $room['price_per_hour'] ?>" required>

                <label>ราคาต่อวัน (บาท) *</label>
                <input type="number" step="0.01" name="price_per_day" value="<?= $room['price_per_day'] ?>" required>

                <label>รายละเอียด</label>
                <textarea name="description" rows="3"><?= htmlspecialchars($room['description']) ?></textarea>

                <div style="margin-top: 20px;">
                    <button type="submit" class="btn primary">บันทึกการแก้ไข</button>
                    <a href="admin.php?tab=rooms" class="btn">ยกเลิก</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>