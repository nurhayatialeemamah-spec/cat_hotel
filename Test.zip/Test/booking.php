<?php
session_start();
require_once __DIR__ . '/db_connect.php';
$conn->set_charset('utf8mb4');
$conn->select_db('cat_hotel');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = intval($_SESSION['user_id']);
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS rooms_qty INT DEFAULT 1");

// ตรวจสอบว่าเป็นโหมดแก้ไขหรือไม่
$is_edit_mode = false;
$edit_booking_id = 0;
$existing_booking = null;
$existing_cats = [];

if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_booking_id = intval($_GET['edit']);

    // ดึงข้อมูลการจองเดิม
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE booking_id=? AND user_id=? AND status='Pending'");
    $stmt->bind_param("ii", $edit_booking_id, $user_id);
    $stmt->execute();
    $existing_booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing_booking) {
        $is_edit_mode = true;

        // ดึงข้อมูลแมวที่จองไว้
        $stmt = $conn->prepare("
            SELECT c.*, bc.food 
            FROM bookings_cats bc 
            JOIN cats c ON bc.cat_id = c.cat_id 
            WHERE bc.booking_id = ?
        ");
        $stmt->bind_param("i", $edit_booking_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $existing_cats[] = $row;
        }
        $stmt->close();
    }
}

$room_id = 0;
if (isset($_GET['room_id']))
    $room_id = intval($_GET['room_id']);
if (isset($_GET['rooms_id']))
    $room_id = intval($_GET['rooms_id']);

// ถ้าเป็นโหมดแก้ไข ให้ใช้ room_id จากการจองเดิม
if ($is_edit_mode && $existing_booking) {
    $room_id = intval($existing_booking['rooms_id']);
}

if ($room_id <= 0) {
    echo "<p>ไม่มี room_id ระบุ — ไปที่ <a href='main.php'>หน้าห้อง</a></p>";
    exit();
}

$rstmt = $conn->prepare("SELECT * FROM rooms WHERE rooms_id=? LIMIT 1");
$rstmt->bind_param("i", $room_id);
$rstmt->execute();
$room = $rstmt->get_result()->fetch_assoc();
$rstmt->close();

if (!$room) {
    die("ห้องนี้ไม่พบข้อมูล");
}

// กำหนดจำนวนแมวสูงสุดและราคาต่อชั่วโมงตามประเภทห้อง
$room_type = $room['type'];
$max_cats_allowed = 1;
$hourly_rate = 100;

switch ($room_type) {
    case 'Standard':
        $max_cats_allowed = 2;
        $hourly_rate = 100;
        break;
    case 'Deluxe':
        $max_cats_allowed = 3;
        $hourly_rate = 150;
        break;
    case 'Suite':
        $max_cats_allowed = 4;
        $hourly_rate = 200;
        break;
    case 'Luxury':
        $max_cats_allowed = 5;
        $hourly_rate = 300;
        break;
    default:
        $max_cats_allowed = intval($room['max_cats'] ?? 1);
        $hourly_rate = floatval($room['price_per_hour'] ?? 100);
}

$foods = [];
$fres = $conn->query("SELECT foods_name, price FROM foods");
while ($row = $fres->fetch_assoc())
    $foods[] = $row;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $start_raw = $_POST['start_date'] ?? '';
    $end_raw = $_POST['end_date'] ?? '';
    $booking_type = $_POST['booking_type'] ?? 'Daily';
    $num_cats = intval($_POST['num_cats'] ?? 1);

    if (!$start_raw || !$end_raw) {
        $error = "กรุณาระบุวันที่เริ่มและวันที่สิ้นสุด";
    } else {
        $start_date = date('Y-m-d H:i:s', strtotime($start_raw));
        $end_date = date('Y-m-d H:i:s', strtotime($end_raw));
        if (strtotime($end_date) <= strtotime($start_date)) {
            $error = "วันที่สิ้นสุดต้องมากกว่าวันที่เริ่ม";
        }
    }

    if ($num_cats > $max_cats_allowed) {
        $error = "ห้อง {$room_type} รองรับได้สูงสุด {$max_cats_allowed} ตัวเท่านั้น";
    }

    $cat_names = $_POST['cat_name'] ?? [];
    $cat_genders = $_POST['cat_gender'] ?? [];
    $cat_ages = $_POST['cat_age'] ?? [];
    $cat_breeds = $_POST['cat_breed'] ?? [];
    $cat_diseases = $_POST['cat_disease'] ?? [];
    $cat_weights = $_POST['cat_weight'] ?? [];
    $cat_allergy = $_POST['cat_allergy'] ?? [];
    $cat_foods = $_POST['cat_food'] ?? [];

    if (!$error) {
        $hours = (strtotime($end_date) - strtotime($start_date)) / 3600.0;
        $days = max(1, ceil($hours / 24.0));

        if ($booking_type === 'Hourly') {
            $price_per_cat = $hourly_rate * max(1, $hours);
        } else {
            $price_per_cat = $room['price_per_day'] * $days;
        }

        $food_total = 0.0;
        foreach ($cat_foods as $fd) {
            if ($fd === 'none' || $fd === '')
                continue;
            $stmt = $conn->prepare("SELECT price FROM foods WHERE foods_name=? LIMIT 1");
            $stmt->bind_param("s", $fd);
            $stmt->execute();
            $r = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($r)
                $food_total += floatval($r['price']) * $days;
        }

        $total_price = floatval($price_per_cat) * $num_cats + $food_total;

        $max_cats_per_room = $max_cats_allowed;
        $required_rooms = (int) ceil(max(1, $num_cats) / $max_cats_per_room);

        $room_capacity = intval($room['capacity'] ?? 1);
        if ($num_cats > ($room_capacity * $max_cats_per_room)) {
            $error = "จำนวนแมวมากเกินกว่าจำนวนห้องทั้งหมดที่มี (สูงสุด " . ($room_capacity * $max_cats_per_room) . " ตัว)";
        } else {
            // ตรวจสอบห้องว่าง
            if ($is_edit_mode) {
                $chk = $conn->prepare("SELECT COALESCE(SUM(rooms_qty),0) AS used FROM bookings
                    WHERE rooms_id = ? AND booking_id != ? AND status IN ('Pending','Confirmed','Paid','Occupied')
                      AND NOT (end_date <= ? OR start_date >= ?)");
                $chk->bind_param("iiss", $room_id, $edit_booking_id, $start_date, $end_date);
            } else {
                $chk = $conn->prepare("SELECT COALESCE(SUM(rooms_qty),0) AS used FROM bookings
                    WHERE rooms_id = ? AND status IN ('Pending','Confirmed','Paid','Occupied')
                      AND NOT (end_date <= ? OR start_date >= ?)");
                $chk->bind_param("iss", $room_id, $start_date, $end_date);
            }

            $chk->execute();
            $used = intval($chk->get_result()->fetch_assoc()['used']);
            $chk->close();

            $available_rooms = max(0, $room_capacity - $used);
            if ($available_rooms < $required_rooms) {
                $error = "ขออภัย ห้องไม่ว่างพอในช่วงเวลาที่เลือก — ต้องการ " . $required_rooms . " ห้อง แต่เหลือเพียง " . $available_rooms . " ห้อง";
            } else {
                if ($is_edit_mode) {
                    // อัปเดตการจองเดิม
                    $upd = $conn->prepare("UPDATE bookings SET start_date=?, end_date=?, booking_type=?, total_price=?, rooms_qty=? WHERE booking_id=?");
                    $upd->bind_param("sssdii", $start_date, $end_date, $booking_type, $total_price, $required_rooms, $edit_booking_id);

                    if ($upd->execute()) {
                        $upd->close();

                        // ลบข้อมูลแมวเดิม
                        $del = $conn->prepare("DELETE FROM bookings_cats WHERE booking_id=?");
                        $del->bind_param("i", $edit_booking_id);
                        $del->execute();
                        $del->close();

                        $booking_id = $edit_booking_id;

                        // เพิ่มข้อมูลแมวใหม่
                        for ($i = 0; $i < $num_cats; $i++) {
                            $name = trim($cat_names[$i] ?? '');
                            if ($name === '')
                                continue;
                            $gender = $cat_genders[$i] ?? '';
                            $age = intval($cat_ages[$i] ?? 0);
                            $breed = $cat_breeds[$i] ?? '';
                            $disease = $cat_diseases[$i] ?? '';
                            $weight = floatval($cat_weights[$i] ?? 0);
                            $allergy = $cat_allergy[$i] ?? '';
                            $food = $cat_foods[$i] ?? 'none';

                            $cstmt = $conn->prepare("SELECT cat_id FROM cats WHERE user_id=? AND name=? LIMIT 1");
                            $cstmt->bind_param("is", $user_id, $name);
                            $cstmt->execute();
                            $cres = $cstmt->get_result();
                            if ($cres && $cres->num_rows > 0) {
                                $cat_id = $cres->fetch_assoc()['cat_id'];
                                $up = $conn->prepare("UPDATE cats SET gender=?, age=?, breed=?, disease=?, weight=?, allergy=? WHERE cat_id=?");
                                $up->bind_param("sissdsi", $gender, $age, $breed, $disease, $weight, $allergy, $cat_id);
                                $up->execute();
                                $up->close();
                            } else {
                                $insc = $conn->prepare("INSERT INTO cats (user_id, name, gender, age, breed, disease, weight, allergy) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                                $insc->bind_param("ississds", $user_id, $name, $gender, $age, $breed, $disease, $weight, $allergy);
                                $insc->execute();
                                $cat_id = $conn->insert_id;
                                $insc->close();
                            }
                            $cstmt->close();

                            $bc = $conn->prepare("INSERT INTO bookings_cats (booking_id, cat_id, food) VALUES (?, ?, ?)");
                            $bc->bind_param("iis", $booking_id, $cat_id, $food);
                            $bc->execute();
                            $bc->close();
                        }

                        header("Location: payment.php?booking_id=" . $booking_id);
                        exit();
                    } else {
                        $error = "เกิดข้อผิดพลาดในการอัปเดตข้อมูล: " . $conn->error;
                    }
                } else {
                    // สร้างการจองใหม่
                    $ins = $conn->prepare("INSERT INTO bookings (user_id, rooms_id, start_date, end_date, booking_type, total_price, rooms_qty, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");
                    $ins->bind_param("iisssdi", $user_id, $room_id, $start_date, $end_date, $booking_type, $total_price, $required_rooms);

                    if ($ins->execute()) {
                        $booking_id = $conn->insert_id;
                        $ins->close();

                        // เพิ่มข้อมูลแมว
                        for ($i = 0; $i < $num_cats; $i++) {
                            $name = trim($cat_names[$i] ?? '');
                            if ($name === '')
                                continue;
                            $gender = $cat_genders[$i] ?? '';
                            $age = intval($cat_ages[$i] ?? 0);
                            $breed = $cat_breeds[$i] ?? '';
                            $disease = $cat_diseases[$i] ?? '';
                            $weight = floatval($cat_weights[$i] ?? 0);
                            $allergy = $cat_allergy[$i] ?? '';
                            $food = $cat_foods[$i] ?? 'none';

                            $cstmt = $conn->prepare("SELECT cat_id FROM cats WHERE user_id=? AND name=? LIMIT 1");
                            $cstmt->bind_param("is", $user_id, $name);
                            $cstmt->execute();
                            $cres = $cstmt->get_result();
                            if ($cres && $cres->num_rows > 0) {
                                $cat_id = $cres->fetch_assoc()['cat_id'];
                                $up = $conn->prepare("UPDATE cats SET gender=?, age=?, breed=?, disease=?, weight=?, allergy=? WHERE cat_id=?");
                                $up->bind_param("sissdsi", $gender, $age, $breed, $disease, $weight, $allergy, $cat_id);
                                $up->execute();
                                $up->close();
                            } else {
                                $insc = $conn->prepare("INSERT INTO cats (user_id, name, gender, age, breed, disease, weight, allergy) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                                $insc->bind_param("ississds", $user_id, $name, $gender, $age, $breed, $disease, $weight, $allergy);
                                $insc->execute();
                                $cat_id = $conn->insert_id;
                                $insc->close();
                            }
                            $cstmt->close();

                            $bc = $conn->prepare("INSERT INTO bookings_cats (booking_id, cat_id, food) VALUES (?, ?, ?)");
                            $bc->bind_param("iis", $booking_id, $cat_id, $food);
                            $bc->execute();
                            $bc->close();
                        }

                        header("Location: payment.php?booking_id=" . $booking_id);
                        exit();
                    } else {
                        $error = "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . $conn->error;
                    }
                }
            }
        }
    }
}

// เตรียมข้อมูลสำหรับแสดงในฟอร์ม
$default_num_cats = $is_edit_mode ? count($existing_cats) : 1;
$default_booking_type = $is_edit_mode ? $existing_booking['booking_type'] : 'Daily';
$default_start = $is_edit_mode ? date('Y-m-d\TH:i', strtotime($existing_booking['start_date'])) : '';
$default_end = $is_edit_mode ? date('Y-m-d\TH:i', strtotime($existing_booking['end_date'])) : '';
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $is_edit_mode ? 'แก้ไขการจอง' : 'จองห้อง' ?> - <?= htmlspecialchars($room['type']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="container section">
        <?php if ($is_edit_mode): ?>
            <div class="alert warn">
                <strong>โหมดแก้ไขการจอง #<?= $edit_booking_id ?></strong> - กรุณาตรวจสอบข้อมูลและกดบันทึกเพื่ออัปเดต
            </div>
        <?php endif; ?>

        <h2><?= $is_edit_mode ? 'แก้ไขการจอง' : 'จองห้อง' ?>: <?= htmlspecialchars($room['type']) ?> Room</h2>

        <div class="alert warn" style="margin: 16px 0;">
            <strong>ข้อมูลห้อง:</strong><br>
            รองรับแมวสูงสุด: <strong><?= $max_cats_allowed ?> ตัว</strong><br>
            ราคารายวัน: <strong><?= number_format($room['price_per_day'], 2) ?> บาท/วัน</strong><br>
            ราคารายชั่วโมง: <strong><?= number_format($hourly_rate, 2) ?> บาท/ชั่วโมง</strong>
        </div>

        <?php if (!empty($success))
            echo "<div class='alert ok'>" . htmlspecialchars($success) . "</div>"; ?>
        <?php if (!empty($error))
            echo "<div class='alert err'>" . htmlspecialchars($error) . "</div>"; ?>

        <form method="post" action="" class="card">
            <label for="num_cats">จำนวนแมว (สูงสุด <?= $max_cats_allowed ?> ตัว)</label>
            <select id="num_cats" name="num_cats" onchange="generateCatForms()">
                <?php for ($i = 1; $i <= $max_cats_allowed; $i++): ?>
                    <option value="<?= $i ?>" <?= ($default_num_cats == $i) ? 'selected' : '' ?>><?= $i ?> ตัว</option>
                <?php endfor; ?>
            </select>

            <label>ประเภทการจอง</label>
            <select name="booking_type" id="booking_type">
                <option value="Daily" <?= ($default_booking_type == 'Daily') ? 'selected' : '' ?>>
                    รายวัน (<?= number_format($room['price_per_day'], 2) ?> บาท/วัน)
                </option>
                <option value="Hourly" <?= ($default_booking_type == 'Hourly') ? 'selected' : '' ?>>
                    รายชั่วโมง (<?= number_format($hourly_rate, 2) ?> บาท/ชั่วโมง)
                </option>
            </select>

            <div class="form-row">
                <div>
                    <label for="start_date">วันที่เริ่ม</label>
                    <input type="datetime-local" id="start_date" name="start_date"
                        value="<?= htmlspecialchars($default_start) ?>" required>
                </div>
                <div>
                    <label for="end_date">วันที่สิ้นสุด</label>
                    <input type="datetime-local" id="end_date" name="end_date"
                        value="<?= htmlspecialchars($default_end) ?>" required>
                </div>
            </div>

            <div id="cats_container" style="margin-top: 20px;"></div>

            <div style="margin-top: 24px; display: flex; gap: 12px;">
                <button type="submit" class="btn primary">
                    <?= $is_edit_mode ? 'บันทึกการแก้ไข' : 'ยืนยันการจอง' ?>
                </button>
                <a href="rooms.php" class="btn">ยกเลิก</a>
            </div>
        </form>
    </div>

    <script>
        const foodOptions = '<?php
        $opts = '<option value="none">ไม่รับอาหารเสริม</option>';
        foreach ($foods as $f) {
            $fn = htmlspecialchars($f['foods_name']);
            $opts .= "<option value=\"{$fn}\">{$fn} ({$f['price']} บาท/วัน)</option>";
        }
        echo str_replace("'", "\\'", $opts);
        ?>';
        const maxCatsAllowed = <?= $max_cats_allowed ?>;
        const existingCats = <?= json_encode($existing_cats) ?>;
        const isEditMode = <?= $is_edit_mode ? 'true' : 'false' ?>;

        function generateCatForms() {
            let container = document.getElementById("cats_container");
            container.innerHTML = "";
            let num = parseInt(document.getElementById("num_cats").value || "1");

            if (num > maxCatsAllowed) {
                num = maxCatsAllowed;
                document.getElementById("num_cats").value = maxCatsAllowed;
            }

            for (let i = 0; i < num; i++) {
                let catData = (isEditMode && existingCats[i]) ? existingCats[i] : {};

                container.innerHTML += `
            <div class="card mt-3">
                <h3 style="margin-top: 0;">แมวตัวที่ ${i + 1}</h3>
                <div class="form-row">
                    <div>
                        <label>ชื่อ *</label>
                        <input type="text" name="cat_name[]" value="${catData.name || ''}" required>
                    </div>
                    <div>
                        <label>เพศ *</label>
                        <select name="cat_gender[]">
                            <option value="Male" ${catData.gender === 'Male' ? 'selected' : ''}>ผู้</option>
                            <option value="Female" ${catData.gender === 'Female' ? 'selected' : ''}>เมีย</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label>อายุ (ปี) *</label>
                        <input type="number" name="cat_age[]" value="${catData.age || ''}" min="0" required>
                    </div>
                    <div>
                        <label>พันธุ์ *</label>
                        <input type="text" name="cat_breed[]" value="${catData.breed || ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div>
                        <label>น้ำหนัก (kg) *</label>
                        <input type="number" step="0.1" name="cat_weight[]" value="${catData.weight || ''}" min="0" required>
                    </div>
                    <div>
                        <label>โรคประจำตัว</label>
                        <input type="text" name="cat_disease[]" value="${catData.disease || ''}" placeholder="ถ้ามี">
                    </div>
                </div>
                <label>แพ้อาหาร/ยา</label>
                <input type="text" name="cat_allergy[]" value="${catData.allergy || ''}" placeholder="ถ้ามี">
                
                <label>อาหารเสริม</label>
                <select name="cat_food[]" id="cat_food_${i}">${foodOptions}</select>
            </div>
        `;
            }

            // ตั้งค่าอาหารที่เลือกไว้
            if (isEditMode) {
                setTimeout(() => {
                    for (let i = 0; i < num; i++) {
                        if (existingCats[i] && existingCats[i].food) {
                            let select = document.getElementById('cat_food_' + i);
                            if (select) {
                                select.value = existingCats[i].food;
                            }
                        }
                    }
                }, 100);
            }
        }

        document.addEventListener("DOMContentLoaded", generateCatForms);
    </script>
</body>

</html>