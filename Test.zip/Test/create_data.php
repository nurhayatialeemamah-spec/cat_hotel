<?php
// เชื่อมต่อฐานข้อมูล MySQL
include("db_connect.php"); // ตรวจสอบชื่อไฟล์ให้ถูกต้อง

$dbname = "cat_hotel";

// ============================
// 1. สร้างฐานข้อมูล cat_hotel
// ============================
$sql = "CREATE DATABASE IF NOT EXISTS $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
if ($conn->query($sql) === TRUE) {
    echo "Database '$dbname' created successfully<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

// เลือกใช้งานฐานข้อมูล
$conn->select_db($dbname);

// ============================
// 2. สร้างตาราง user
// ============================
$sql_user = "
CREATE TABLE IF NOT EXISTS user (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) UNIQUE,
    surname VARCHAR(30),
    email VARCHAR(50),
    password VARCHAR(255),
    phone VARCHAR(10),
    role VARCHAR(10),
    address VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
if ($conn->query($sql_user) === TRUE) {
    echo "Table 'user' created successfully<br>";
} else {
    echo "Error creating table 'user': " . $conn->error . "<br>";
}

// ============================
// Insert default admin user (if not exists)
// ============================
$admin_username = 'admin';
$admin_email = 'admin@email.com';
$admin_password_plain = 'admin123'; // change this after first run
$admin_password = password_hash($admin_password_plain, PASSWORD_DEFAULT);
$admin_surname = 'Administrator';
$admin_phone = '0900000000';
$admin_role = 'admin';
$admin_address = 'Head Office';

// Check if admin user already exists by username or email
$checkStmt = $conn->prepare("SELECT user_id FROM user WHERE username = ? OR email = ? LIMIT 1");
if ($checkStmt) {
    $checkStmt->bind_param('ss', $admin_username, $admin_email);
    $checkStmt->execute();
    $checkStmt->store_result();
    if ($checkStmt->num_rows === 0) {
        $checkStmt->close();
        $insertStmt = $conn->prepare("INSERT INTO user (username, surname, email, password, phone, role, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($insertStmt) {
            $insertStmt->bind_param('sssssss', $admin_username, $admin_surname, $admin_email, $admin_password, $admin_phone, $admin_role, $admin_address);
            if ($insertStmt->execute()) {
                echo "Default admin user inserted (username: $admin_username)<br>";
            } else {
                echo "Error inserting admin user: " . $insertStmt->error . "<br>";
            }
            $insertStmt->close();
        } else {
            echo "Prepare failed for admin insert: " . $conn->error . "<br>";
        }
    } else {
        echo "Admin user already exists, skipping insertion<br>";
        $checkStmt->close();
    }
} else {
    echo "Prepare failed for admin check: " . $conn->error . "<br>";
}

// ============================
// 3. สร้างตาราง rooms
// ============================
$sql_rooms = "
CREATE TABLE IF NOT EXISTS rooms (
    rooms_id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50),
    size VARCHAR(30),
    capacity INT,
    price_per_hour DECIMAL(10,2),
    price_per_day DECIMAL(10,2),
    image VARCHAR(255),
    status ENUM('Available','Occupied') DEFAULT 'Available',
    max_cats INT,
    extra_cat_price DECIMAL(10,2),
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
$conn->query($sql_rooms) ? print ("Table 'rooms' created<br>") : print ("Error 'rooms': " . $conn->error . "<br>");

// เพิ่ม 4 ห้องตัวอย่าง
$sample_rooms = [
    ['Standard', '3x3 m', 2, 100, 500, 'room01.jpg', 2, 50, 'ห้องมาตรฐาน'],
    ['Deluxe', '4x4 m', 3, 150, 800, 'room02.jpg', 3, 70, 'ห้องดีลักซ์'],
    ['Suite', '5x5 m', 4, 200, 1200, 'room03.jpg', 4, 100, 'ห้องสวีท'],
    ['Luxury', '6x6 m', 5, 300, 2000, 'room04.jpg', 5, 150, 'ห้องหรูสุด']
];
foreach ($sample_rooms as $r) {
    $stmt = $conn->prepare("INSERT INTO rooms (type,size,capacity,price_per_hour,price_per_day,image,max_cats,extra_cat_price,description) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param(
        "ssiidisds",
        $r[0], // type (string)
        $r[1], // size (string)
        $r[2], // capacity (int)
        $r[3], // price_per_hour (int/decimal)
        $r[4], // price_per_day (int/decimal)
        $r[5], // image (string)
        $r[6], // max_cats (int)
        $r[7], // extra_cat_price (decimal)
        $r[8]  // description (string)
    );
    $stmt->execute();
}
// ============================
// 4. สร้างตาราง bookings
// ============================
$sql_bookings = "CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    rooms_id INT NOT NULL,
    bookking_status VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    booking_type VARCHAR(50) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Available','Occupied') DEFAULT 'Available',
    FOREIGN KEY (user_id) REFERENCES user(user_id),
    FOREIGN KEY (rooms_id) REFERENCES rooms(rooms_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";  // Removed extra parenthesis here



if ($conn->query($sql_bookings) === TRUE) {
    echo "Table 'bookings' created successfully<br>";
} else {
    echo "Error creating table 'bookings': " . $conn->error . "<br>";
}

// ============================
// 5. สร้างตาราง cats
// ============================
$sql_cats = "
CREATE TABLE IF NOT EXISTS cats (
    cat_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(30),
    gender VARCHAR(10),
    age INT,
    breed VARCHAR(30),
    disease VARCHAR(30),
    weight INT,
    allergy VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
if ($conn->query($sql_cats) === TRUE) {
    echo "Table 'cats' created successfully<br>";
} else {
    echo "Error creating table 'cats': " . $conn->error . "<br>";
}

// ============================
// 6. สร้างตาราง bookings_cats
// ============================
$sql_bookings_cats = "
CREATE TABLE IF NOT EXISTS bookings_cats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    cat_id INT NOT NULL,
    food VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (cat_id) REFERENCES cats(cat_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
if ($conn->query($sql_bookings_cats) === TRUE) {
    echo "Table 'bookings_cats' created successfully<br>";
} else {
    echo "Error creating table 'bookings_cats': " . $conn->error . "<br>";
}

// ============================
// 7. สร้างตาราง expensens
// ============================
$sql_expensens = "
CREATE TABLE IF NOT EXISTS expensens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(50),
    amount DECIMAL(10,2),
    detail VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
if ($conn->query($sql_expensens) === TRUE) {
    echo "Table 'expensens' created successfully<br>";
} else {
    echo "Error creating table 'expensens': " . $conn->error . "<br>";
}

// ============================
// 8. สร้างตาราง foods
// ============================
// สร้างตาราง foods
$sql_foods = "
CREATE TABLE IF NOT EXISTS foods (
    foods_id INT AUTO_INCREMENT PRIMARY KEY,
    foods_name VARCHAR(50),
    price DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($conn->query($sql_foods) === TRUE) {
    echo "Table 'foods' created successfully<br>";
} else {
    echo "Error creating table 'foods': " . $conn->error . "<br>";
}

// เพิ่มรายการอาหาร
$sample_foods_cats = [
    ['อาหารแมวเกรดพรีเมี่ยม Buzz', 309.00],
    ['อาหาร Kaniva productnation', 499.00],
    ['อาหาร Hills Science Diet productnation', 559.00]
];

$sql_insert = "INSERT INTO foods (foods_name, price) VALUES ";

$values = [];
foreach ($sample_foods_cats as $fc) {
    $name = $conn->real_escape_string($fc[0]); // ป้องกัน SQL Injection
    $price = $fc[1];
    $values[] = "('$name', $price)";
}

$sql_insert .= implode(", ", $values);

// รันคำสั่ง SQL
if ($conn->query($sql_insert) === TRUE) {
    echo "ข้อมูลอาหารถูกเพิ่มเรียบร้อยแล้ว<br>";
} else {
    echo "Error adding data: " . $conn->error . "<br>";
}




// ============================
// 9. สร้างตาราง payment
// ============================
$sql_payment = "
CREATE TABLE IF NOT EXISTS payment (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    amount DECIMAL(10,2),
    payment_date DATETIME,
    payment_method VARCHAR(50),
    status ENUM('Pending','Paid') DEFAULT 'Pending',
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";
if ($conn->query($sql_payment) === TRUE) {
    echo "Table 'payment' created successfully<br>";
} else {
    echo "Error creating table 'payment': " . $conn->error . "<br>";
}


header("Location: index.php");
$conn->close();
?>