<?php

require_once __DIR__ . '/db_connect2.php';

function h($s)
{
  return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

$sql = "SELECT r.rooms_id, r.size, r.price_per_day, r.status, r.capacity,
        COALESCE(b.used,0) AS used_rooms,
        (r.capacity - COALESCE(b.used,0)) AS available_rooms
        FROM rooms r
        LEFT JOIN (
          SELECT rooms_id, COALESCE(SUM(rooms_qty),0) AS used
          FROM bookings
          WHERE status IN ('Pending','Confirmed','Paid','Occupied')
            AND NOT (end_date <= NOW() OR start_date >= NOW())
          GROUP BY rooms_id
        ) b ON r.rooms_id = b.rooms_id
        WHERE (r.capacity - COALESCE(b.used,0)) > 0
        ORDER BY r.price_per_day ASC, r.rooms_id ASC
        LIMIT 4";

$rooms_result = $conn->query($sql);

$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['name'] ?? '';
$role = $_SESSION['role'] ?? null;

function roomImagePath($roomId)
{
  $base = 'assets/images/';
  $candidates = [
    $base . "room{$roomId}.jpg",
    $base . "room{$roomId}.png",
    $base . 'room-default.jpg',
  ];
  foreach ($candidates as $path) {
    if (is_file(__DIR__ . '/' . $path))
      return $path;
  }
  return $base . 'room-default.jpg';
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <title>Cat Hotel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
    rel="stylesheet">

  <style>
    * {
      font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
    }
  </style>
</head>

<body>
  <div class="container section">
    <div class="topbar">
      <h1 class="section-title" style="margin-right:auto">🐾 Cat Hotel</h1>
      <?php if ($user_id): ?>
        <span>สวัสดี <?= h($user_name) ?></span>
        <a class="btn" href="logout.php">ออกจากระบบ</a>
        <?php if ($role === 'admin' || $role === 'staff'): ?>
          <a class="btn" href="admin.php">แดชบอร์ด</a>
        <?php else: ?>
          <a class="btn" href="dashboard.php">แดชบอร์ด</a>
        <?php endif; ?>
      <?php else: ?>
        <a class="btn" href="login.php">เข้าสู่ระบบ</a>
        <a class="btn" href="register.php">สมัครสมาชิก</a>
        <a class="btn" href="admin.php">Admin</a>
      <?php endif; ?>
    </div>

    <h2>แพ็กเกจห้องพัก</h2>
    <?php if (!$rooms_result || $rooms_result->num_rows === 0): ?>
      <p class="muted">ยังไม่มีห้องว่างให้จองขณะนี้</p>
    <?php else: ?>
      <div class="rooms">
        <?php while ($row = $rooms_result->fetch_assoc()): ?>
          <?php
          $roomId = (int) $row['rooms_id']; // ให้ประกาศภายใน loop
          $sizeNote = (string) $row['size'];
          $perNight = (float) $row['price_per_day'];
          $name = "ห้องหมายเลข #" . $roomId;
          $img = roomImagePath($roomId);
          ?>
          <div class="room-card">
            <img src="<?= h($img) ?>" alt="<?= h($name) ?>"
              onerror="this.onerror=null;this.src='assets/images/room-default.jpg'">
            <div class="content">
              <h3><?= h($name) ?></h3>
              <div class="meta">ขนาด: <?= h($sizeNote) ?></div>
              <div class="price">ราคา/คืน: <?= number_format($perNight, 2) ?> บาท</div>
              <div style="margin-top:10px">
                <?php if ($user_id): ?>
                  <a class="btn primary" href="rooms.php?room_id=<?= $roomId ?>">จอง</a>
                <?php else: ?>
                  <a class="btn" href="login.php">กรุณาเข้าสู่ระบบเพื่อจอง</a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>

    <section id="pricing" class="py-5 bg-light mt-4">
      <div class="container">
        <h2 class="section-title">อัตราการบริการ & สิ่งอำนวยความสะดวก</h2>
        <div class="grid">
          <div class="pricing-box">
            <h5 class="mb-2">แพ็กเกจและราคา (สรุป)</h5>
            <ul class="mb-0 small muted">
              <li>Standard Room — 350 ฿ / คืน (1-2 ตัว)</li>
              <li>Standard Plus — 590 ฿ / คืน (3 ตัว)</li>
              <li>VIP Room — 750 ฿ / คืน (3-4 ตัว)</li>
              <li>VIP Plus — 1,290 ฿ / คืน (6-8 ตัว)</li>
              <li>ตัวเพิ่ม +50 ฿ / ตัว / คืน</li>
            </ul>
          </div>
          <div class="pricing-box">
            <h5 class="mb-2">สิ่งอำนวยความสะดวก (รายละเอียด)</h5>
            <ul class="mb-0 small muted">
              <li>ชามอาหาร / ชามน้ำ (แยกโซนเมื่อจำเป็น)</li>
              <li>กระบะทราย + ที่ตักส่วนตัว (ทรายเบนโทไนท์ฟรี)</li>
              <li>กล่องนอน • ชั้นปีนป่าย • แผ่นลับเล็บ</li>
              <li>ห้องน้ำแมวส่วนตัว (VIP)</li>
              <li>CCTV + พี่เลี้ยงดูแล 24 ชม.</li>
              <li>อัปเดตรูปภาพรายวัน</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section id="contact" class="mt-4">
      <h2>ติดต่อเรา</h2>
      <div class="card">
        <div><strong>โทร:</strong> 098-888-8888</div>
        <div><strong>ที่อยู่:</strong> 181 หมู่ที่ 6 ถนนเจริญประดิษฐ์ ตำบลรูสะมิแล อำเภอเมือง จังหวัดปัตตานี 94000</div>
        <div class="socials mt-1">
          <h5 style="word-spacing: 40px;">Facebook Instagram TikTok</h5>
        </div>
      </div>
    </section>
  </div>
</body>

</html>