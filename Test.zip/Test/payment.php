<?php
session_start();
include("db_connect.php");

if (!isset($_GET['booking_id']) || !is_numeric($_GET['booking_id'])) {
    die("booking_id ไม่ถูกต้อง");
}
$booking_id = intval($_GET['booking_id']);

$stmt = $conn->prepare("
    SELECT b.*, r.type AS room_type, r.rooms_id
    FROM bookings b 
    JOIN rooms r ON b.rooms_id=r.rooms_id
    WHERE b.booking_id=?
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
    die("ไม่พบการจองนี้");
}

// ดึงข้อมูลแมว + อาหาร
$stmt = $conn->prepare("SELECT c.name, c.gender, c.age, c.breed, c.disease, c.weight, c.allergy, bc.food 
                        FROM bookings_cats bc 
                        JOIN cats c ON bc.cat_id = c.cat_id 
                        WHERE bc.booking_id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$cats_res = $stmt->get_result();

if (!$cats_res) {
    die("Error executing query: " . $conn->error);
}

$cat_list = [];
$num_days = 1;
$unique_foods = [];

$start = new DateTime($booking['start_date']);
$end = new DateTime($booking['end_date']);
$interval = $start->diff($end);
$num_days = max($interval->days, 1);

while ($c = $cats_res->fetch_assoc()) {
    $food_price = 0;
    $food_name = $c['food'];

    if ($food_name && $food_name !== "none") {
        if (!isset($unique_foods[$food_name])) {
            $stmt = $conn->prepare("SELECT price FROM foods WHERE foods_name=?");
            $stmt->bind_param("s", $food_name);
            $stmt->execute();
            $res = $stmt->get_result()->fetch_assoc();

            $unique_foods[$food_name] = ($res['price'] ?? 0);
        }

        $food_price = $unique_foods[$food_name] * $num_days;
    }

    $c['food_price'] = $food_price;
    $cat_list[] = $c;
}

$food_total = 0;
foreach ($unique_foods as $price) {
    $food_total += $price * $num_days;
}

$room_price = $booking['total_price'] - $food_total;

// ประมวลผลการชำระเงิน
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $payment_method = $_POST['payment_method'];
    $amount = $booking['total_price'];

    $stmt = $conn->prepare("INSERT INTO payment (booking_id, amount, payment_method, status) VALUES (?, ?, ?, 'Paid')");
    $stmt->bind_param("ids", $booking_id, $amount, $payment_method);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE bookings SET status='Occupied' WHERE booking_id=?");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();

    $stmt = $conn->prepare("
        UPDATE rooms 
        SET status='Occupied' 
        WHERE rooms_id = (SELECT rooms_id FROM bookings WHERE booking_id=?)
    ");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();

    echo "<script>alert('ชำระเงินเรียบร้อย! สถานะห้องและการจองถูกอัปเดตแล้ว'); window.location.href='dashboard.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ยืนยันการชำระเงิน</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
    <style>
        body {
            background: var(--bg);
            font-family: var(--font);
        }

        .payment-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        .payment-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: white;
            padding: 30px;
            border-radius: var(--radius);
            margin-bottom: 24px;
            text-align: center;
        }

        .payment-header h2 {
            margin: 0 0 10px;
            font-size: 28px;
        }

        .booking-summary {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }

        .summary-row:last-child {
            border-bottom: none;
        }

        .summary-label {
            color: var(--muted);
            font-weight: 500;
        }

        .summary-value {
            font-weight: 600;
            color: var(--text);
        }

        .cat-section {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
        }

        .cat-item {
            background: #fff7fa;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 12px;
        }

        .cat-item h4 {
            margin: 0 0 12px;
            color: var(--primary);
            font-size: 18px;
        }

        .cat-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
            font-size: 14px;
        }

        .cat-detail-item {
            display: flex;
            gap: 8px;
        }

        .detail-label {
            color: var(--muted);
            font-weight: 600;
        }

        .food-info {
            margin-top: 12px;
            padding: 10px;
            background: var(--accent);
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
        }

        .price-summary {
            background: #fff7fa;
            border: 2px solid var(--primary);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 20px;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            font-size: 16px;
        }

        .price-row.total {
            border-top: 2px solid var(--primary);
            margin-top: 12px;
            padding-top: 16px;
            font-size: 20px;
            font-weight: 700;
            color: var(--primary);
        }

        .payment-form {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text);
        }

        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 16px;
        }

        .button-group {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-edit,
        .btn-pay {
            flex: 1;
            padding: 16px;
            border: none;
            border-radius: 999px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-edit {
            background: var(--surface);
            color: var(--text);
            border: 2px solid var(--border);
        }

        .btn-edit:hover {
            border-color: var(--primary);
            color: var(--primary);
            transform: translateY(-2px);
        }

        .btn-pay {
            background: var(--primary);
            color: white;
        }

        .btn-pay:hover {
            background: var(--primary-600);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(245, 158, 182, .4);
        }

        .btn-back {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 12px;
            background: var(--surface);
            color: var(--text);
            text-align: center;
            text-decoration: none;
            border: 1px solid var(--border);
            border-radius: 999px;
            transition: all 0.3s;
        }

        .btn-back:hover {
            background: var(--bg);
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .cat-details {
                grid-template-columns: 1fr;
            }

            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <div class="payment-container">
        <div class="payment-header">
            <h2>ยืนยันการชำระเงิน</h2>
            <p style="margin: 0;">หมายเลขการจอง: #<?php echo $booking_id; ?></p>
        </div>

        <div class="booking-summary">
            <h3 style="margin-top: 0; color: var(--text);">สรุปการจอง</h3>
            <div class="summary-row">
                <span class="summary-label">ประเภทห้อง:</span>
                <span class="summary-value"><?php echo htmlspecialchars($booking['room_type']); ?> Room</span>
            </div>
            <div class="summary-row">
                <span class="summary-label">ประเภทการจอง:</span>
                <span
                    class="summary-value"><?php echo $booking['booking_type'] === 'Daily' ? 'รายวัน' : 'รายชั่วโมง'; ?></span>
            </div>
            <div class="summary-row">
                <span class="summary-label">วันที่เข้าพัก:</span>
                <span class="summary-value"><?php echo date('d/m/Y H:i', strtotime($booking['start_date'])); ?></span>
            </div>
            <div class="summary-row">
                <span class="summary-label">วันที่คืนห้อง:</span>
                <span class="summary-value"><?php echo date('d/m/Y H:i', strtotime($booking['end_date'])); ?></span>
            </div>
            <div class="summary-row">
                <span class="summary-label">ระยะเวลาพัก:</span>
                <span class="summary-value"><?php echo $num_days; ?> วัน</span>
            </div>
            <div class="summary-row">
                <span class="summary-label">จำนวนแมว:</span>
                <span class="summary-value"><?php echo count($cat_list); ?> ตัว</span>
            </div>
        </div>

        <?php if (count($cat_list) > 0): ?>
            <div class="cat-section">
                <h3 style="margin-top: 0; color: var(--text);">รายละเอียดแมว</h3>
                <?php foreach ($cat_list as $index => $cat): ?>
                    <div class="cat-item">
                        <h4>แมวตัวที่ <?php echo ($index + 1); ?>: <?php echo htmlspecialchars($cat['name']); ?></h4>
                        <div class="cat-details">
                            <div class="cat-detail-item">
                                <span class="detail-label">เพศ:</span>
                                <span><?php echo $cat['gender'] === 'Male' ? 'ผู้' : 'เมีย'; ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">อายุ:</span>
                                <span><?php echo $cat['age']; ?> ปี</span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">พันธุ์:</span>
                                <span><?php echo htmlspecialchars($cat['breed']); ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">น้ำหนัก:</span>
                                <span><?php echo $cat['weight']; ?> กก.</span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">โรคประจำตัว:</span>
                                <span><?php echo $cat['disease'] ?: '-'; ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">อาหารที่แพ้:</span>
                                <span><?php echo $cat['allergy'] ?: '-'; ?></span>
                            </div>
                        </div>
                        <?php if ($cat['food'] !== "none" && $cat['food']): ?>
                            <div class="food-info">
                                <strong>อาหารเสริม: <?php echo htmlspecialchars($cat['food']); ?></strong>
                                <span><?php echo number_format($cat['food_price'], 2); ?> บาท</span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="price-summary">
            <h3 style="margin: 0 0 16px; color: var(--text);">สรุปยอดชำระ</h3>
            <div class="price-row">
                <span>ค่าห้องพัก</span>
                <span><?php echo number_format($room_price, 2); ?> บาท</span>
            </div>
            <div class="price-row">
                <span>ค่าอาหารเสริม</span>
                <span><?php echo number_format($food_total, 2); ?> บาท</span>
            </div>
            <div class="price-row total">
                <span>ยอดชำระทั้งหมด</span>
                <span><?php echo number_format($booking['total_price'], 2); ?> บาท</span>
            </div>
        </div>

        <form method="POST" class="payment-form">
            <h3 style="margin-top: 0; color: var(--text);">ชำระเงิน</h3>
            <div class="form-group">
                <label for="payment_method">เลือกวิธีชำระเงิน</label>
                <select name="payment_method" id="payment_method" required>
                    <option value="">-- เลือกวิธีชำระเงิน --</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>

                </select>
            </div>

            <div class="button-group">
                <button type="button" class="btn-edit"
                    onclick="window.location.href='booking.php?room_id=<?php echo $booking['rooms_id']; ?>&edit=<?php echo $booking_id; ?>'">
                    แก้ไขการจอง
                </button>
                <button type="submit" class="btn-pay">
                    ยืนยันการชำระเงิน
                </button>
            </div>
        </form>

        <a href="main.php" class="btn-back">กลับไปหน้าหลัก</a>
    </div>
</body>

</html>