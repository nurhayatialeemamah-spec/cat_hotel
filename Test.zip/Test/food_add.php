<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';

// ถ้ามี ID แสดงว่าเป็นการแก้ไข
$edit_mode = false;
$food = null;

if (isset($_GET['id'])) {
    $edit_mode = true;
    $food_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM foods WHERE foods_id = ?");
    $stmt->bind_param("i", $food_id);
    $stmt->execute();
    $food = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$food) {
        header("Location: admin.php?tab=foods");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['foods_name']);
    $price = floatval($_POST['price']);

    if (empty($name)) {
        $error = "กรุณาระบุชื่ออาหาร";
    } elseif ($price <= 0) {
        $error = "กรุณาระบุราคาที่ถูกต้อง";
    } else {
        if ($edit_mode) {
            // อัปเดตข้อมูล
            if ($conn->query("UPDATE foods SET foods_name='$name', price=$price WHERE foods_id=$food_id")) {
                header("Location: admin.php?tab=foods&success=updated");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        } else {
            // เพิ่มข้อมูลใหม่
            if ($conn->query("INSERT INTO foods (foods_name, price) VALUES ('$name', $price)")) {
                header("Location: admin.php?tab=foods&success=added");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit_mode ? 'แก้ไขอาหาร' : 'เพิ่มอาหารใหม่' ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <!-- แบบที่ 2: โมเดิร์น หรูหรา สไตล์ร่วมสมัย -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
    <style>
        .user-detail-container {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
        }

        .form-group small {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 0.9em;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }
    </style>
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button" style="margin-bottom: 20px;">
            <a href="admin.php?tab=foods" class="btn">← กลับ</a>
        </div>

        <div class="content-card">
            <h2><?= $edit_mode ? '✏️ แก้ไขอาหาร' : '➕ เพิ่มอาหารใหม่' ?></h2>

            <?php if ($error): ?>
                <div class="alert err"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>ชื่ออาหาร *</label>
                    <input type="text" name="foods_name" placeholder="เช่น อาหารแมวพรีเมี่ยม Buzz"
                        value="<?= $edit_mode ? htmlspecialchars($food['foods_name']) : '' ?>" required>
                    <small>ชื่อเต็มของอาหารแมว</small>
                </div>

                <div class="form-group">
                    <label>ราคาต่อวัน (บาท) *</label>
                    <input type="number" step="0.01" name="price" min="0" placeholder="0.00"
                        value="<?= $edit_mode ? $food['price'] : '' ?>" required>
                    <small>ราคาอาหารต่อวันต่อตัว</small>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn primary">
                        <?= $edit_mode ? '💾 บันทึกการแก้ไข' : '➕ เพิ่มอาหาร' ?>
                    </button>
                    <a href="admin.php?tab=foods" class="btn">❌ ยกเลิก</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>