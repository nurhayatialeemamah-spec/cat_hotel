<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "cat_hotel";  // <-- เพิ่มบรรทัดนี้

// สร้าง connection
$conn = new mysqli($servername, $username, $password, $database);

// ตรวจสอบ connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
